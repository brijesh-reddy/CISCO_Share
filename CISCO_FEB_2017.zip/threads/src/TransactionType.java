
public enum TransactionType {
	DEBIT, CREDIT
}
