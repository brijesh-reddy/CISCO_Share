import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallTest {

	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(2);
		Future<Integer> f1 = service.submit(new Counter(1,3333));
		Future<Integer> f2 = service.submit(new Counter(100,4000));
		Future<Integer> f3 = service.submit(new Counter(22,101));
		Future<Integer> f4 = service.submit(new Counter(1,10));
		
		try {
			System.out.println(f1.get());
			System.out.println(f2.get());
			System.out.println(f3.get());
			System.out.println(f4.get());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		
		service.shutdown();
	}

}
