package exception;

public class Test {

	public static void main(String[] args) {
		String s = new String("D");
		doTask(s,"Good");
		doTask(s,"Good","Bad");
		doTask(s);
	}

	private static void doTask(String... str) {
		 System.out.println(str[0]);
		 System.out.println(str[1]);
	}

}
