package exception;

public class SecondExample {

	public static void main(String[] args) {
		System.out.println("Start...");
		doTask();
		System.out.println("End...");
	}

	private static void doTask() {
		int[] elems = {10,4};
		System.out.println(elems[6]);
	}

}
