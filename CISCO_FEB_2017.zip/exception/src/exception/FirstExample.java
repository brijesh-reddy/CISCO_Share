package exception;

public class FirstExample {

	public static void main(String[] args) {
		System.out.println("Start...");
		doTask();
		System.out.println("End...");
	}

	private static void doTask() {
		int x = 10;
		int y = 0;
		System.out.println(x/y);
	}

}
