package exception;

public class ErrorFirstExample {
	
	static {
		System.loadLibrary("goPockemon.dll");
	}
	public static void main(String[] args) {
		System.out.println("Start...");
	}

}
