package exception;

public class ErrorSecExample {
	 
	public static void main(String[] args) {
		System.out.println("Start...");
		doTask();
	}

	private static void doTask() {
		System.out.println("Hello");
		doTask();
	}

}
