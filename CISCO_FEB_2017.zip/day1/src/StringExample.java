
public class StringExample {
	
	/*
	 * Email should contain @, ends with .com or .org or .edu or .co.in
	 */
	public static boolean isEmailValid(String email) {
		String emailEx = "[a-zA-Z][a-zA-Z0-9_]*@[a-z]{3,}(.com|.edu|.org|.co.in)";
		return email.matches(emailEx);
	}
	
	/*
	 * Name should be min 3 characters and max of 15 characters
	 * Name should contain only alphabhets , no digits or special character
	 */
	public static boolean isNameValid(String name) {
		return false;
	}
}
