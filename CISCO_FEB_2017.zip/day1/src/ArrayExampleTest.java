import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayExampleTest {

	@Test
	public void testGetSum() {
		int[] data = {4,2,6};
		int expectedResult = 12;
		assertEquals(expectedResult, ArrayExample.getSum(data));
	}

	@Test
	public void testGetOccurence() {
		int[] vals = {4,2,6,7,2,4,10,2};
		int expectedResult = 3;
		assertEquals(expectedResult, ArrayExample.getOccurence(vals, 2));
		assertEquals(2, ArrayExample.getOccurence(vals, 4));
		assertEquals(1, ArrayExample.getOccurence(vals, 10));
		assertEquals(0, ArrayExample.getOccurence(vals, 32));
	}

	@Test
	public void testSort() {
		int[] vals = {4,2,6,7,2,4,10,2};
		int[] expected = {2,2,2,4,4,6,7,10};
		ArrayExample.sort(vals);
		assertArrayEquals(expected, vals);
	}

}
