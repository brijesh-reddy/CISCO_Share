
public class FirstExample {

	public static void main(String[] args) {
		int x = 10;
		int y = 15;
		int result = add(x,y);
		System.out.println("Result : " + result);
	}

	private static int add(int x, int y) {
		return x + y;
	}

}
