import static org.junit.Assert.*;

import org.junit.Test;

public class StirngExampleTest {

	@Test
	public void testIsEmailValid() {
		assertEquals(true, StringExample.isEmailValid("banu@gmail.com"));
		assertEquals(false, StringExample.isEmailValid("banugmail.com"));
		assertEquals(true, StringExample.isEmailValid("banu@yahoo.co.in"));
	}

	@Test
	public void testIsNameValid() {

		assertEquals(true, StringExample.isNameValid("Raj"));
		assertEquals(false, StringExample.isNameValid("Raj3"));
	}

}
