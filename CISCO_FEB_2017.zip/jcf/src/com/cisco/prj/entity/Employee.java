package com.cisco.prj.entity;

import com.cisco.prj.annotation.Column;
import com.cisco.prj.annotation.Table;

@Table(name="EMP")
public class Employee {
	private int id;
	private String name;
	/**
	 * @return the id
	 */
	@Column(name="EMP_ID", type="INTEGER")
	public int getId() {
		return id;
	}
	/**
	 * @return the name
	 */
	@Column(name="EMP_NAME")
	public String getName() {
		return name;
	}
	
	
}
