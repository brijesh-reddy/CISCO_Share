package com.cisco.prj.client;

public class Test {

	public static void main(String[] args) {
		String one = "Aa";
		String two = "BB";
		String three = "Aa";
		String four = "DA";
		
		System.out.println(one.hashCode());
		System.out.println(two.hashCode());
		System.out.println(three.hashCode());
		System.out.println(four.hashCode());
	}

}
