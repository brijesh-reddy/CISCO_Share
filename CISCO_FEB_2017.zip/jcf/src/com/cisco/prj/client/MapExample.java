package com.cisco.prj.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		Map<String,Double> bookPriceMap = new HashMap<String,Double>();
		
		bookPriceMap.put("Java", 450.00);
		bookPriceMap.put("Hadoop", 3500.50);
		bookPriceMap.put("JavaScript", 200.00);
		
		System.out.println(bookPriceMap.get("Hadoop")); // 3500.00
		
		Set<String> keys = bookPriceMap.keySet();
		
		for(String key : keys) {
			System.out.println(key  + " : " + bookPriceMap.get(key));
		}
	}

}
