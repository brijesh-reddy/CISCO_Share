package com.cisco.prj.client;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.cisco.prj.entity.Product;

public class SetExample {

	public static void main(String[] args) {
		// Set<Product> products = new HashSet<Product>();
		// Set<Product> products = new TreeSet<Product>(); // comparable
		Set<Product> products = new TreeSet<Product>(new Comparator<Product>() {
			@Override
			public int compare(Product o1, Product o2) {
				int diff = Double.compare(o1.getPrice(), o2.getPrice());
				if (diff == 0) {
					diff = o1.getId() - o2.getId();
				}
				return diff;
			}
		});

		products.add(new Product(134, "iPhone 7", 74000.00, "mobile"));
		products.add(new Product(521, "Sony Bravia", 94000.00, "tv"));
		products.add(new Product(100, "Cannon Printer", 24000.00, "computers"));
		products.add(new Product(572, "Seagate HDD", 5300.00, "computers"));
		products.add(new Product(92, "MotoG", 12999.00, "mobile"));
		products.add(new Product(134, "iPhone 7", 74000.00, "mobile"));

		System.out.println("Enhanced For loop");
		for (Product product : products) {
			System.out.println(product);
		}

		System.out.println("Iterator");
		Iterator<Product> iter = products.iterator();
		while (iter.hasNext()) {
			Product p = iter.next();
			System.out.println(p);
		}
	}

}
