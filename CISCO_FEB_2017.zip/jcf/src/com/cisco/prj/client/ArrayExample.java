package com.cisco.prj.client;

import java.util.Arrays;
import java.util.Comparator;

public class ArrayExample {
	public static void main(String[] args) {
		String[] names = { "David", "Lee", "Angelina", "Brad", "Adele" };
		// Arrays.sort(names, new LengthComparator());
		Arrays.sort(names, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				int diff = o1.length() - o2.length();
				return (diff == 0) ? o1.compareTo(o2) : diff;
			}
		});
		for (String name : names) {
			System.out.println(name);
		}
	}
}

/*class LengthComparator implements Comparator<String> {
	@Override
	public int compare(String o1, String o2) {
		int diff = o1.length() - o2.length();
		return (diff == 0) ? o1.compareTo(o2) : diff;
	}
}*/