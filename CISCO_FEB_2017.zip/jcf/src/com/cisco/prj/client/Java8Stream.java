package com.cisco.prj.client;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class Java8Stream {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(12,5,7,82,11,20);
		
		Function<Integer, Integer> func = (d) -> d * 2;
		
		
		list.stream().map(func).forEach(d -> System.out.println(d));
		list.stream().map(func).forEach(System.out::println);
		
		System.out.println("Filtered...");
		list.stream().filter((d) -> d%2 == 0).map(func).forEach(d -> System.out.println(d));
		
		System.out.println("Reduce...");
		double total = list.stream().reduce(0,(a,b) -> a+b);
		System.out.println(total);
	}

}
