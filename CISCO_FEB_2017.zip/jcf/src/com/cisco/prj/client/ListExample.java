package com.cisco.prj.client;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.cisco.prj.entity.Product;

public class ListExample {

	public static void main(String[] args) {
		List<Product> products = new LinkedList<Product>();
		products.add(new Product(134,"iPhone 7", 74000.00,"mobile"));
		products.add(new Product(521,"Sony Bravia", 94000.00,"tv"));
		products.add(new Product(100,"Cannon Printer", 24000.00,"computers"));
		products.add(new Product(572,"Seagate HDD", 5300.00,"computers"));
		products.add(new Product(92,"MotoG", 12999.00,"mobile"));
		products.add(new Product(134,"iPhone 7", 74000.00,"mobile"));
		
//		Collections.sort(products); // natural sort uses Comparable interface
	
		Collections.sort(products, new Comparator<Product>() {
			@Override
			public int compare(Product o1, Product o2) {
				if(o1.getPrice() > o2.getPrice()) {
					return 1;
				} else if(o2.getPrice() > o1.getPrice()) {
					return -1;
				}
				return 0;
			} 
		});
		System.out.println("Traverse using index");
		for (int i = 0; i < products.size() ; i++) {
			Product p = products.get(i);
			System.out.println(p);
		}
		
		System.out.println("Enhanced For loop");
		for (Product product : products) {
			System.out.println(product);
		}

		System.out.println("Iterator");
		Iterator<Product> iter = products.iterator();
		while(iter.hasNext()) {
			Product p = iter.next();
			System.out.println(p);
		}
	}

}
