package com.cisco.prj.client;

import com.cisco.prj.entity.Product;
import com.cisco.prj.util.DbUtil;

public class SQLClient {

	public static void main(String[] args) {
		String createSQL = DbUtil.generateCreateStatement(Product.class);
		System.out.println(createSQL);
		
		Product p = new Product(100,"Hp Laptop",45550.00,"computer");
		String insertSQL = DbUtil.generateInsertSQL(p);
		
		System.out.println(insertSQL); // insert sql for product
	}

}
