package com.cisco.prj.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.cisco.prj.entity.Product;

public class Java8FirstExample {

	public static void main(String[] args) {
		List<Product> products = new LinkedList<Product>();
		products.add(new Product(134, "iPhone 7", 74000.00, "mobile"));
		products.add(new Product(521, "Sony Bravia", 94000.00, "tv"));
		products.add(new Product(100, "Cannon Printer", 24000.00, "computers"));
		products.add(new Product(572, "Seagate HDD", 5300.00, "computers"));
		products.add(new Product(92, "MotoG", 12999.00, "mobile"));
		products.add(new Product(134, "iPhone 7", 74000.00, "mobile"));

		System.out.println("Map : Get Names of Product");

		products.parallelStream().map(p -> p.getName()).forEach(System.out::println);

		List<String> names =
				products.parallelStream().map(p -> p.getName()).collect(Collectors.toList());
		
		System.out.println(names);
		
		System.out.println("Get only mobiles");
		
		List<Product> mobiles = 
				products.parallelStream().filter(p -> p.getCategory().equals("mobile"))
				.collect(Collectors.toList());
		
		mobiles.forEach(m -> System.out.println(m.getName() + "," + m.getCategory()));
		
		System.out.println("************");
		Map<String, List<Product>> productGroup = 
				products.stream().collect(Collectors.groupingBy(p -> p.getCategory()));
		
		productGroup.forEach((k,v) -> {
			System.out.println(k);
			v.forEach(p -> System.out.println(p.getName()));
		});
		
	

		
		/*
		 * Consumer<Product> cons = new Consumer<Product>() {
		 * 
		 * @Override public void accept(Product t) {
		 * System.out.printf("\n%5d%15s%12.2f", t.getId(),
		 * t.getName(),t.getPrice()); } };
		 * 
		 * products.forEach(cons);
		 * 
		 * System.out.println("Java 8 way"); products.forEach( (t) -> {
		 * System.out.printf("\n%5d%15s%12.2f", t.getId(),
		 * t.getName(),t.getPrice()); });
		 */
	}

}
