package com.cisco.prj.client;

import java.util.HashSet;
import java.util.Set;

public class Set2Example {

	public static void main(String[] args) {
		String sentence = "Java is OOP Java is Platform independent";
		String[] words = sentence.split(" ");
		
		Set<String> unique = new HashSet<String>();
		Set<String> dups = new HashSet<String>();
		
		for(String word : words) {
			if(!unique.add(word)) {
				dups.add(word);
			}
		}
		unique.removeAll(dups);
		System.out.println(unique);
		System.out.println(dups);
	}

}
