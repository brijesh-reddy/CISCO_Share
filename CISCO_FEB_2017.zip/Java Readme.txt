
Java

Banu Prakash C
banuprakashc@yahoo.co.in
https://github.com/BanuPrakash/CISCO_Share
-------------------------

Softwares Required:

JDK 1.8
Eclipse for JEE (Mars or latest)
MySQL DB / HSQLDB

---------------------------------

	OOP ( Object oriented Paradigm)

	Writing programs which resemble real world application

	SOLID Design Principles:

	S ---> Single Resposnibility
	O ---> Open Close Principle
	L ---> Liskov Substitution Principle
	I ---> Interface segreggation
	D ---> Dependency Injection ( Inversion Of Control )

	------------

	What is Java?

		Java is a Technology.

		Java provides the platform to execute byte code.

		ByteCode is a compiled code

		Source Code ---> compile ----> Byte Code

		.java  --------> javac  ----> .class

		.groovy  ------> groovy -----> .class

----------------------------------------------------------------------------

	Example.java

	public class Example {
		public static void main(String[] args) {
			int x = 10;
			int y = 15;
			doTask(x,y);
		}

		public static void doTask(int a, int b) {
			int result = a + b;
			System.out.println("Result : " + result);
		}
	}


	$ javac Example.java

	Example.class is generated

	$ java Example
------------------------------------

Primitive type 										Reference Type

byte  ( 1 byte)											Array
short ( 2 )												Object
int (4 )
long  (8)

float ( 4)
double ( 8)

char ( 2 )
boolean ( 1 )


	byte b = 10;
	byte c = 15;

	byte d = (byte) (b + c);

------------------------------------------------------------------

	Arrays are reference type.
	Memory is allocated on Heap area and its pointers are on stack.
	Every array contains a "length" member which holds the size of array.


	int[] values  = new int[3];

	int[] data = {4,6,266,2};


--------------------------------------------------------------------

	Object oriented Programming with Java.

	Object holds state and behavior

	State of an object is represented by its instance variables
	Behaviours are exposed as actions/ methods of object

	Every object contains state and behavoir
	Class is an template to hold this information

	public class Account {
		// state of object
		private String accNo;
		private double balance;
	}


	Account rahulAcc = new Account();
	Account swethaAcc = new Account();

	rahulAcc.balance = 5000.00; // error [ private ]

	General practice in OOP is make state private and behaviour public.


	Adding Behaviour



	public class Account {
		// state of object
		private String accNo;
		private double balance;

		public  void deposit(double amt) { // public  void deposit(Account this, double amt) {
			balance += amt;					// this.balance += amt;
		}
	}


	Account rahulAcc = new Account();
	Account swethaAcc = new Account();

	// before the period operator is the context,
	// after the period operator is the behavior
	rahulAcc.deposit(4500.00); // deposit(rahulAcc, 4500.00);

---------------------------------------------------------------

	Logical grouping of classes

	1) entity / domain / model classes 
	2) exception classes
	3) Business Classes
	4) DAO [ Data Access Object ] class
	5) Service classes
	6) Utility classes [ Helpers]
	7) UI [ User Interface ]
---------------------------

	Comments

	Programmer comments

	/*
			Multiline

	*/


	// single line


	API comments / JavaDoc Comments

	/**


	*/
-------------------------------------

	== Vs equal()

	equals() is for comparing state of object

	== is comparing references [ Same ]
---------------------------------------------------------------

	Naming Conventions:

	Use Camel case for class, methods and variables

	Use Snake case for Constants MAX_AGE

	Class name should start with Uppercase character
	methods and var should start with lowercase


	public Tea getMeTea() {


	}


	public Tea getmetea() {

	}
---------------------------------------------------------------------------------------------

 Day 2:
 ------
 Relationship between objects

 1) Generalization and Specialization
 2) Realization
 3) Assoication
 4) Uses A Relationship

 ---------------------------

 	public class Product {

 	}

 	public class Mobile extends Product {

 	}

 	Product p = new Product();

 	Product p = new Mobile(); // valid Upcasting


 	Mobile m = new Product(); // not valid [ Downcasting]
 	-----------------

 	public class Product {
 		public Product() {
 			prints p1
 		}
 		public Product(int id, String name) {
 			prints p2
 		}
 	}

 	public class Mobile extends Product {
 		public Mobile() {
 			prints m1
 		}

 		public Mobile(int id, String name, String camera) {
 			prints m2
 		}
 	}


 	new Mobile(); // p1 and m1

 	new Mobile(1,"MotoG", "12MP"); // p1 and m2


 	public Mobile(int id, String name, String camera) {
 			super(id,name);
 			prints m2
 		}
 	new Mobile(1,"MotoG", "12MP"); // p2 and m2

 ---------------------------------------------------------------


 	public class Product {
 		protected double getPrice () {
 			return 100;
 		}
 	}

 	public class Mobile extends Product {
 		public String getCamera() {
 			return "12MP";
 		}
 		protected double getPrice () { //override
 			return 200;
 		}
 	}

 	Mobile m = new Mobile();
 	m.getPrice(); // 200
 	m.getCamera(); // 12MP

 	Product p = new Mobile();
 		p.getPrice(); //  200
 		p.getCamera(); //  ERROR

-----------------------------------------------------------------------------
Visibility
private : only within the class
public : any where
protected: visible within the class, inhereited class and anywhere within the same package
default: within the package [ package private ]


public class Document {
		private Document() {
			//code
		}

		public static Document getDocument() {
			Document d = new Document();
			d.setThat();
			d.setThis();
			d.doSomeThingElse();
			return d;
		}
}

Document d = Document.getDocument();

Document d= new Documnet(); // error
---------------------------------------------------------------

Realization RelationShip

A component will realize the behavior specifed by other in order to communicate.

Realization RelationShip is done using interface.


	interface Flyable {
		fly();
	}


	class Bird implements Flyable {
		fly() {
			// logic
		}
	}

	class AeroPlance implements Flyable {
			fly() {
				//logic
			}
	}

	class SuperMan implements Flyable {
		fly() {
				//logic
			}
	}

	---------------------------------------------

	Why Program to interface?

		a) DESIGN
		b) IMPLEMENTATION
		c) TESTING
		d) INTEGRATION


	package : com.cisco.prj.dao

	Name: MobileDao


	package: com.cisco.prj.dao

	class: MobileDaoDbImpl

	interface : MobileDao


	class: MobileDaoCloudImpl
	interface : MobileDao
-------------------------------------------------------------------


	ClassLoader loads the class

	Rectangle r = new Rectangle();

	String s;

	String str="com.ciso.prj.dao.MobileDaoCloudImpl";

	return Class.forName(str).newInstance();


	dbconfig.properties
-----------------------------------------

 interface Swim {									Swim s = new Hero();
 	swim();												s.swim();
 }														s.fight(); // error

 													Fight f = (Fight) s;
 														 f.fight(); // valid
 interface Dance {
 	dance();
 }

 interface Fight {
 	fight();
 }

 class Actor implements Dance {
 	dance() {
 		// code
 	}
 }

 class Hero extends Actor implements Swim, Fight {
 	swim() { }
 	fight() { }
 }

 ------------------------------------------------------

 OCP ( open close principle)
 	Code is closed for a change but open for extension


 	interface IComparable {
 		int difference(Object obj);
 	}


 	void sort(IComparable[] elem) {
 		for(i = 0 ; .... ){
 			for( j = .....) {
 				if(elem[i].difference(elem[j]) > 0 ) {
 					swap code
 				}
 			}
 		}
 	}

 	class Book implements IComparable {
 			int difference(Object obj) {
 				// logic
 			}
 	}


 	package: com.cisco.prj.util



 	Book
 		title
 		price

 	Create 3 or 4 books and sort them based on title

 	REuse IComparable and sort() function
---------------------------------------------------------------------------

Day 3:
------
	
		Java Collection Framework
		provides data containers.

		Array is a data container.
			In Array issues:
			1) Size is fixed
			2) Adding/Removing from arbitrary position is difficult
			3) Needs Contiguos memory

		Java Collection framework provides:
		1) interfaces
		2) implementation classes 
		3) Algorithm classes

List 								Set
1) Supports duplicates 				Unique
2) Ordered 							storage depends on algorithm
3) Re-Ordered						Can't
4) Supports index based oper 		does not support


	David, Lee, Angelina, Brad, Adele

	Sorted O/p: 
	Adele, Angelina, Brad, David, Lee

	Why not:

	Lee, Brad, Adele, David, Angelina

------------------------------------------------

	Generics

	public class Rectangle {
		byte width;
		byte breadth;
	}

	Rectangle r1 = new Rectangle(2,9);

	Rectangle r2 = new Rectangle(1002,3339);

	Rectangle r3 = new Rectangle(1.2,3.9);


	Generic class:

	public class Rectangle<T> {
		T width;
		T breadth;
	}

	Rectangle<Byte> r1 = new Rectangle<Byte>(2,9);

	Rectangle<Integer> r2 = new Rectangle<Integer>(1002,3339);

	Rectangle<Double> r3 = new Rectangle<Double>(1.2,3.9);

	-------

	int x  = 10;
	Integer iX = x; // boxing

	int y = iX; // unboxing


	public class MyStore<T1,T2> {
		T1 var1;
		T2 var2;

		boolean completed;
		int count = 0;
	}


	MyStore<Integer, String> m;



	public class Rectangle<T> {  ===> public class Rectangle {
		T width;							Object width;
		T breadth;							Object breadth;
	}								  }

	Rectangle<Integer> r2 = new Rectangle<Integer>(1002,3339);
	REactangle<String> r = new REctangle<String>("Hello", "World"); // valid


	public class Rectangle<T extends Number> {  ===> public class Rectangle {
		T width;										Number width;
		T breadth;										Number breadth;
	}											  }

 ------------------------

 	List list = new ArrayList();

 	list.add(2);
 	list.add(3.4);
 	list.add("Good Day");


 	List<Integer> list = new ArrayList<Integer>();
 	list.add(2); //valid
 	list.add(3.4); // error
-----------------------------------------------------	


	interface IComparable {
		int difference(Object obj);
	}

	class Book implements IComparable {

			public int difference(Object obj) {
				Book other = (Book) obj;
				//
			}
	}

	interface IComparable<T> {
		int difference(T obj);
	}

	class Book implements IComparable<Book> {

			public int difference(Book obj) {
		  
			}
	}
-------------------------------------

	Anonymous class [ Class without a name]

	interface Flyable {
		void fly();
	}

	class Bird implements Flyable {
		public void fly() {
			// code
		}
	}

	Flyable f = new Flyable(); // error
	Flyable eagle = new Bird();
	Flyable crow = new Bird();

	Flyable f = new Flyable() {
		public void fly() {
			Jump from 4th floor
		}
	}


	interface Collection {
		Iterator iterator();
	}


	class LinkedList implements List {

		Iterator iterator() {
			return the firs node
		}
	}
------------------------------------------------------


	public class Rectangle {
		int w, b;

		int hashCode() {
			return 2pow 0 * w + 2pow 1 * b;
		}
	}

	REactangle(4,5);
	REactangle(5,4);
	REactangle(10,2);
	REactangle(20,1);
	REactangle(1,20);
--------------------------------------------------------

Exception Handling
------------------
	Any abnormal condition that arises dureing program execution is an exception.

	In Java exception is an object.
	Object gives the following information:
	a) What went wrong?
	b) Why did it go wrong?
	c) Where?
-----------------------------------

Exception type of Exceptions can be classfied into:

Checked type 									Unchecked Type

a) Compiler enforces you to handle 				compiler does not enforce
b) they happen due to reasons outside JRE 		reasons are with JRE
												(handle using conditional statement)



For checked type of exceptions we use the following syntax:

	try {
		//actual code to execute
	} catch(IOException ex) {
		// handling code
	} catch(SQLException ex) {
		// handling code
	} finally {
		// optional block to release resource
	}
-----------------------------------------------------------------------

	Annotation

	Metadata

	@Override


	public class A {
		protected void test() { "Bad"}
		public void test(int x) { "Bad"}
		public void test(String s) { "Bad"}
	}

	public class B extends A {
	    @Override
		public void test() {"Good"}
	}

	Override rules:

	1) method names should be same
	2) access modifiers can be same or enhanced
	3) Return type can be same type or subtype


	class Account {
		Account getAccount() {

		}
	}


	class SavingsAccount extends Account {

		SavingsAccount getAccount() {

		}
	}
	------------------------------------------------------------------

	Annotations can be used by:
	1) Compiler
		@Override
	2) ClassLoader

	3) JRE
		@Test



		@Mobile(os="android")
		class PokemonGo extends Game {

		}

  --------------------------------------------

   @Table(name="BOOKS")
   public class Book {

   		@Column("BOOK_ID", type="Numeric")
   		int id;	
   		@Column("BOOK_TITLE")
   		String title;

   		
   }

   createStatment(Class class);

   save(Object obj)
===================================================================

	Java Concurrent Programming (Multi Threaded applications)
	---------------------------------------------------------

	A Single threaded app will have one unit of work [ Main Thread]
	Example:
		Notepad, Calculator

	In Multi threaded application we can have many concurrent units of work [threads]
	executing
		Example:
			Eclipse, Word, Excel

	---------

	Java Provides Runnable interface for implementing threads:

	interface Runnable {
		void run() ; // entry point for the thread
	}

	for the main thread main() is the entry point


	Thread class provides thread control methods:
	1) start()
	2) sleep(long ms)
	3) yield()
	4) join()
	5) interrupt()

	deprecated methods:
	6) stop()
	7) suspend()
	8) resume()
 -------------------------------

 	Thread Safety

 	A member is said to be thread safe if it does not get corrupted in multithreaded
 	environment.


 	Local var ---> SAFE ---> Reside on Stack --> Each thread has a seperate stack


 	instance and static --> Not Safe --> Heap area and loaded classes are shared

 	volatile members ---> Safe --> 

 	volatile [ no - optimization ]

 	volatile boolean flag = false;

 	Only atomic variables should be marked as volatile
 	boolean is atomic

 	

 	public class BankingService {

 		public  void transferFunds(Account from, Account to , double amt){
 			synchronized(from) {
 				synchronized(to) {
 					from.withdraw(amt);
 					to.depoist(amt);
 				}
 			}
 		}
 	}
 ---------------------------------------------------------------------

 JDBC
 ----

 MySQL Community Server


 mysql -u root -p

 create database cisco_java;

 use cisco_java;

 create table movies (id int primary key auto_increment, title varchar(100), year int);

insert into movies values(0,'Life Of PI', 2013);
insert into movies values(0,'Spectre', 2014);

select * from movies;

-------------------

	JDBC --- > Java Database connectivity
		is an Integration API to interact with RDBMS

	Java <---> JDBC <---> Drivers Provided by Database Vendors <----> Database


	Java provides interfaces

	Database vendors provides implemenation classes

	Database vendor implementation classes are provided in the form "jar" files

	Maven Project
		Maven is a build tool which helps in
		dependecy managment.


	MovieDaoDbImpl
--------------------------------------------

	DriverManager is used to create connection based on URL passed.

	Statement, PreparedStatement and CallableStatement are used to 
	send SQL to database

	Use Statement if "SQL" is fixed [ No IN PARAMETERS]


	Use PreparedStatement if "SQL" contains IN Paramters like:
	1) INSERT INTO movies (id, title, year) VALUES (0,?, ?)
	2) SELECT * FROM movies WHERE year = ?
	3) DELETE FROM movies WHERE year = ?


	Use CallableStatement if you need to invoke "Stored Procedures" of DB.
----------------------------------------------------------------------------

 Java 8 Features
 ---------------

 1) Functional interface
 	functional interface is one which contain only one method to implement

 	Prior to Java 8:

 	Thread t = new Thread(new Runnable() {
 		public void run() {
 			for(int i = 0 ; i < 10; i++) {
 				System.out.println("Hello :"  +i);
 			} 
 		}
 	});

 	t.start();

 	Java 8:

 	Thread t = new Thread( () -> {
 		for(int i = 0 ; i < 10; i++) {
 				System.out.println("Hello :"  +i);
 			} 
 	});

------------------------------------------------------------

	Functional Style of Programming using Java 8.

	In OOP methods deals with state of object

	Common functions:
	map
	filter
	reduce
	sort
	forEach
-------------------

Java IO

