package com.cisco.prj.dao;

import java.util.List;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public interface MovieDao {
	
	List<Movie> getMovies() throws FetchException;
	
	void addMovie(Movie movie) throws PersistenceException;
}
