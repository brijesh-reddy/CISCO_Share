package com.cisco.prj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public class MovieDaoDbImpl implements MovieDao {

	static String DRIVER = DBConfig.getString("DB_DRIVER"); //$NON-NLS-1$
	static String URL = DBConfig.getString("DB_URL"); //$NON-NLS-1$
	static String USER = DBConfig.getString("DB_USER"); //$NON-NLS-1$
	static String PASSWORD = DBConfig.getString("DB_PWD"); //$NON-NLS-1$

	static {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public List<Movie> getMovies() throws FetchException {
		String SQL = "SELECT id, title, year FROM movies";
		List<Movie> movies = new ArrayList<Movie>();
		Connection con = null;
		try {
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				Movie m = 
						new Movie(rs.getInt("id"), rs.getString("title"), rs.getInt("year"));
				movies.add(m);
			}
		} catch (SQLException e) {
			throw new FetchException("unable to get movies", e);
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return movies;
	}

	public void addMovie(Movie movie) throws PersistenceException {
		String SQL = "INSERT INTO movies(id, title, year) VALUES (0,?,?)";
		Connection con = null;
		try {
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.setString(1, movie.getTitle());
			ps.setInt(2, movie.getYear());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("unable to add movie " + movie.getTitle(), e);
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
