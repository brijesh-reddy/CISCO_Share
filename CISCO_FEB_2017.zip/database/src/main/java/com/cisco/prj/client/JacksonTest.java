package com.cisco.prj.client;

import com.cisco.prj.entity.Movie;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JacksonTest {

	public static void main(String[] args) throws Exception{
		Movie m = new Movie(122,"Test", 2011);
		ObjectMapper mapper = new ObjectMapper();
 		mapper.writeValue(System.out, m);
		
		String s = "{\"id\":122,\"title\":\"Best\",\"year\":2017}";
		
		ObjectMapper mapper2 = new ObjectMapper();
		Movie d =  mapper2.readValue(s, Movie.class);
		
		System.out.println(d.getTitle());
	}

}
