package com.cisco.prj.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public class MovieDaoFileImpl implements MovieDao {

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
		FileReader reader = null;
		try {
			reader = new FileReader("products.csv");
			BufferedReader br = new BufferedReader(reader);
			String line = null;
			while((line = br.readLine()) != null) {
				String[] data = line.split(",");
				Movie m = new Movie();
				m.setId(Integer.parseInt(data[0].trim()));
				m.setTitle(data[1].trim());
				m.setYear(Integer.parseInt(data[2].trim()));
				movies.add(m);
			}
		} catch (IOException e) {
			throw new FetchException("unable to read...");
		}
		return movies;
	}

	public void addMovie(Movie movie) throws PersistenceException {
		FileOutputStream fout = null;
		try {
			fout = new FileOutputStream("products.csv", true);
			PrintStream ps = new PrintStream(fout);
			ps.println(movie.getId() +", " + movie.getTitle() + ", " + movie.getYear());
		} catch (FileNotFoundException e) {
			 throw new PersistenceException("unable to add movie ", e);
		} finally {
			if( fout != null) {
				try {
					fout.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
