package com.cisco.prj.client;

import java.util.List;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.MovieDaoJsonImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;

public class FetchClient {

	public static void main(String[] args) {
		MovieDao movieDao = new MovieDaoJsonImpl();
		
		try {
			List<Movie> movies = movieDao.getMovies();
			for(Movie m : movies) {
				System.out.println(m.getId() + ", " + m.getTitle() + ", " + m.getYear());
			}
		} catch (FetchException e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

}
