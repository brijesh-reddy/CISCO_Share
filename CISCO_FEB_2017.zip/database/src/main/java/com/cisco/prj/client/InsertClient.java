package com.cisco.prj.client;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.MovieDaoJsonImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.PersistenceException;

public class InsertClient {

	public static void main(String[] args) {
//		MovieDao movieDao = new MovieDaoDbImpl();
		MovieDao movieDao = new MovieDaoJsonImpl();
		try {
			Movie m1 = new Movie(3,"Raees", 2017);
			movieDao.addMovie(m1);
			Movie m2 = new Movie(4,"Kaabil", 2017);
			movieDao.addMovie(m2);
			System.out.println("Movie Added!!!");
		} catch (PersistenceException e) {
			// e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

}
