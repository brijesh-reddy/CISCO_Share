/**
 * 
 */
package com.cisco.prj.dao;

import com.cisco.prj.entity.Mobile;

/**
 * @author Banu Prakash
 *
 */
public interface MobileDao {
	/**
	 * method to add a mobile
	 * 
	 * @param mobile
	 *            mobile to persist.
	 */
	void addMobile(Mobile mobile);
}
