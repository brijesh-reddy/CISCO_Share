/**
 * 
 */
package com.cisco.prj.entity;

/**
 * @author Banu Prakash
 * @version 1.0
 * @since FEB 2017
 * 
 *        Entity class to represent account business data.
 */
public class Account {
	// state of object
	private double balance;
	private String accNo;
	
	private static int count; // class member
	
	/**
	 * default constructor
	 */
	public Account() {
		this.accNo = null;
		this.balance = 0.0;
		count++;
	}

	/**
	 * parameterized construtor
	 * @param no account no
	 */
	public Account(String no) {
		this.accNo = no;
		count++;
	}

	/**
	 * 
	 * @param amt
	 *            amount to credit
	 */
	public void deposit(double amt) {
		this.balance += amt;
	}

	/**
	 * 
	 * @param amt
	 *            amount to debit
	 */
	public void withdraw(double amt) {
		this.balance -= amt;
	}

	/**
	 * 
	 * @return current balance
	 */
	public double getBalance() {
		return this.balance;
	}
	
	public String getAccno() {
		return this.accNo;
	}
	
	public static int getCount() {
		return count;
	}
	
	//third.equals(second)
	@Override
	public boolean equals(Object obj) {
		Account other = (Account) obj;
		if(this.accNo.equals(other.accNo) && this.balance == other.balance) {
			return true;
		}
		return false;
	}
	
	
}
