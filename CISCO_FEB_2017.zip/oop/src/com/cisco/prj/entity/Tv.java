/**
 * 
 */
package com.cisco.prj.entity;

/**
 * @author Banu Prakash
 *
 */
public class Tv extends Product {
	private String screen;

	/**
	 * 
	 */
	public Tv() {
	}

	/**
	 * @param id
	 * @param name
	 * @param price
	 * @param screen
	 */
	public Tv(int id, String name, double price, String screen) {
		super(id, name, price);
		this.screen = screen;
	}

	/**
	 * @return the screen
	 */
	public String getScreen() {
		return screen;
	}

	/**
	 * @param screen the screen to set
	 */
	public void setScreen(String screen) {
		this.screen = screen;
	}
	

	/* (non-Javadoc)
	 * @see com.cisco.prj.entity.Product#isExpensive()
	 */
	@Override
	public boolean isExpensive() {
		if(this.screen.equals("CRT") && getPrice() > 3000) {
			return true;
		} else if("LED".equals(this.screen) && getPrice() > 45000) {
			return true;
		}
		return false;
	}
}

 
