package com.cisco.prj.entity;

import com.cisco.prj.util.IComparable;

public class Book implements IComparable {
	private String title;
	private double price;
	
	public Book() {
	}
	
	/**
	 * @param title
	 * @param price
	 */
	public Book(String title, double price) {
		this.title = title;
		this.price = price;
	}
	

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public int difference(Object obj) {
		Book other = (Book) obj;
		return this.title.compareTo(other.title); // unicode difference
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Book [title=" + title + ", price=" + price + "]";
	}
	
}
