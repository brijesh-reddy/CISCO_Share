package com.cisco.prj.client;

import com.cisco.prj.entity.Account;

public class AccountClient {

	public static void main(String[] args) {
		System.out.println(Account.getCount());
		Account first = new Account();
		System.out.println(Account.getCount());
		Account second = new Account("SB100");
		System.out.println(Account.getCount());
		
		Account third = new Account("SB100");
		
		Account fourth = first;
		
		if(fourth == first) {
			System.out.println("4th and 1st are same");
		}
		
		if(third.equals(second)) {
			System.out.println("3rd and 2nd have same content");
		}
		
		first.deposit(3000.00);
		second.deposit(4500.00);
		
		second.withdraw(250.00);
		
		System.out.println("First A/C");
		System.out.println("No:" + first.getAccno());
		System.out.println("Balance : " + first.getBalance());
		

		System.out.println("Second A/C");
		System.out.println("No:" + second.getAccno());
		System.out.println("Balance : " + second.getBalance());
	}

}
