package com.cisco.prj.client;

import com.cisco.prj.dao.MobileDao;
import com.cisco.prj.dao.MobileDaoFactory;
import com.cisco.prj.entity.Mobile;

public class MobileClient {

	public static void main(String[] args) {
		Mobile m = new Mobile(1, "iPhone 7", 70000.00, "4G LTE");
//		MobileDao mobileDao = new MobileDaoCloudImpl();
		MobileDao mobileDao = MobileDaoFactory.getMobileDao();
		mobileDao.addMobile(m);
	}

}
