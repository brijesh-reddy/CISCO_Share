package com.cisco.prj.client;

import com.cisco.prj.entity.Mobile;
import com.cisco.prj.entity.Product;
import com.cisco.prj.entity.Tv;

public class ProductClient {

	public static void main(String[] args) {
		Product[] products = new Product[4];
		products[0] = new Mobile(1,"Pixel",80000.00,"4G");
		products[1] = new Tv(2,"Onida",3000.00, "CRT");
		products[2] = new Mobile(3,"MotoG",9999.00,"4G");
		products[3] = new Tv(4,"Sony Bravia",90000.00, "LED");
		
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i].getName() + "," + products[i].getPrice());
			if(products[i].isExpensive()) { // polymorphism [ Dynamic binding ]
				System.out.println("Expensive one!!!");
			}
			if(products[i] instanceof Mobile) {
				Mobile m = (Mobile) products[i];
				System.out.println(m.getConnectivity());
			}
			if(products[i].getClass() == Tv.class) {
				Tv t = (Tv) products[i];
				System.out.println(t.getScreen());
			}
			System.out.println("**********");
		}
	}

}
