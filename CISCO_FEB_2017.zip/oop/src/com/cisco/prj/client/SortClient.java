/**
 * 
 */
package com.cisco.prj.client;

import com.cisco.prj.entity.Book;
import com.cisco.prj.entity.Mobile;
import com.cisco.prj.util.Utility;

/**
 * @author Banu Prakash
 *
 */
public class SortClient {
	public static void main(String[] args) {
		Mobile[] mobiles = new Mobile[4];
		mobiles[0] = new Mobile(1,"iPhone 7", 70000.00, "4G");
		mobiles[1] = new Mobile(2,"MotoG", 12999.00, "4G");
		mobiles[2] = new Mobile(3,"Nexus",45000.00,"4G");
		mobiles[3] = new Mobile(4,"Samsung J7",21000.00,"4G");
		
		Utility.sort(mobiles);
		
		for (Mobile mobile : mobiles) {
			System.out.println(mobile);
		}
		
		Book[] books = new Book[3];
		books[0] = new Book("def", 355.44);
		books[1] = new Book("xyz", 563.22);
		books[2] = new Book("abc",666.33);
		
		Utility.sort(books);
		
		for (Book book : books) {
			System.out.println(book);
		}
	}
}
