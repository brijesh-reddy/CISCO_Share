package com.cisco.prj.dao;

import java.util.List;

import com.cisco.prj.entity.Movie;

public interface MovieDao {
	void addMovie(Movie movie);

	List<Movie> getMovies();

}
