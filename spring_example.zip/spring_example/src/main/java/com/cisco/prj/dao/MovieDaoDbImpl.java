package com.cisco.prj.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cisco.prj.entity.Movie;

@Repository
public class MovieDaoDbImpl implements MovieDao {
	
	@PersistenceContext
	private EntityManager em;
	@Override
	public void addMovie(Movie movie) {
		em.persist(movie);
	}

	@Override
	public List<Movie> getMovies() {
		TypedQuery<Movie> query = em.createQuery("select m from Movie m", Movie.class);
		return query.getResultList();
	}

}
