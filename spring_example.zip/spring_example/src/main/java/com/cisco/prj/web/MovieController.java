package com.cisco.prj.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;

@Controller
public class MovieController {
	@Autowired
	private MovieDao movieDao;
	
	@RequestMapping(value="/addMovie.do")
	public String addMovie() {
		return "index.html";
	}
	@RequestMapping(value="getMovies.do")
	public String getMovies(Model model) {
		model.addAttribute("movies",movieDao.getMovies());
		return "list.jsp";
	}
	
	@RequestMapping(value="getMoviesJson.do")
	public @ResponseBody List<Movie> getMoviesJSON( ) {
		return movieDao.getMovies();
	}
}
