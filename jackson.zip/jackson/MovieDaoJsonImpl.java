package com.cisco.prj.dao;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

public class MovieDaoJsonImpl implements MovieDao {

	public List<Movie> getMovies() throws FetchException {
		List<Movie> list = new ArrayList<Movie>();
		try {
			FileReader reader = new FileReader("movies.json");
			BufferedReader br = new BufferedReader(reader);
			StringBuilder builder = new StringBuilder();
			String line = null;
			while((line = br.readLine()) != null) {
				builder.append(line);
			}
			ObjectMapper mapper = new ObjectMapper();
			CollectionType javaType = mapper.getTypeFactory()
				      .constructCollectionType(List.class, Movie.class);
			
			list = mapper.readValue(builder.toString(), javaType);
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		return list;
	}

	public void addMovie(Movie movie) throws PersistenceException {
		 ObjectMapper mapper = new ObjectMapper();
		 List<Movie> movies;
		try {
			movies = getMovies();
			movies.add(movie);
			FileOutputStream fout  = new FileOutputStream("movies.json");
			mapper.writeValue(fout, movies);
		} catch (FetchException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		 
	}

}
