package com.cisco.prj.dao.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public class MovieDaoDbImpl implements MovieDao {
	
	private Logger logger = Logger.getLogger(MovieDaoDbImpl.class);
	
	private static String SELECT_MOVIES = "select id, name, release_date from movies";
	
	private static String INSERT_MOVIE = "insert into movies values (0,?,?)";
	
	public void addMovie(Movie movie) throws PersistenceException {
		logger.info("Entered addMovie method");
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_MOVIE);
			ps.setString(1, movie.getName());
			ps.setDate(2, new java.sql.Date(movie.getReleaseDate().getTime()));
			ps.executeUpdate();
		} catch (SQLException e) {
			logger.error("Exception : " + e);
			throw new PersistenceException("unable to add movie", e);
		} finally {
			DBUtil.closeConnection(con);
		}
		logger.info("completed addMovie method");
	}

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SELECT_MOVIES);
			while(rs.next()) {
				movies.add(new Movie(rs.getInt("id"), rs.getString("name"),
						rs.getDate("release_date")));
			}
		} catch (SQLException e) {
			throw new FetchException("unable to get movies", e);
		} finally {
			DBUtil.closeConnection(con);
		}
		return movies;
	}

}
