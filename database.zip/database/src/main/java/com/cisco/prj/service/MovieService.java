/**
 * 
 */
package com.cisco.prj.service;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.file.MovieDaoFileImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.entity.Movies;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

/**
 * @author Banu Prakash
 *
 */
public class MovieService {

	public String movieToXml() throws FetchException, JAXBException {
		MovieDao movieDao = new MovieDaoFileImpl();
			List<Movie> moviesList = movieDao.getMovies();
			JAXBContext jaxbContext = JAXBContext.newInstance(Movies.class);
		    Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		    jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		    ByteArrayOutputStream out = new ByteArrayOutputStream();
		    Movies movies = new Movies();
		    movies.setMovies(moviesList);
		    jaxbMarshaller.marshal(movies, out);
		    return new String(out.toByteArray());
	}
	
	public void xmlToMovie(String strXml) throws JAXBException, PersistenceException {
		 JAXBContext jaxbContext = JAXBContext.newInstance(Movie.class);
		 Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		 StringReader reader = new StringReader(strXml);
		 Movie m = (Movie) jaxbUnmarshaller.unmarshal(reader);
		 MovieDao movieDao = new MovieDaoFileImpl();
		 movieDao.addMovie(m);
	}
}
