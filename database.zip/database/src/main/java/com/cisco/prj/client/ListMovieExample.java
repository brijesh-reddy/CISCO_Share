package com.cisco.prj.client;

import java.util.List;

import javax.xml.bind.JAXBException;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.file.MovieDaoFileImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.service.MovieService;

public class ListMovieExample {

	public static void main(String[] args) {
		//MovieDao movieDao = new MovieDaoDbImpl();
		/*MovieDao movieDao = new MovieDaoFileImpl();
		try {
			List<Movie> movies = movieDao.getMovies();
			for(Movie m : movies) {
				System.out.println(m.getName() + "," + m.getReleaseDate());
			}
		} catch (FetchException e) {
			e.printStackTrace();
			//System.out.println(e.getMessage());
		}*/
		MovieService service = new MovieService();
		try {
			System.out.println(service.movieToXml());
		} catch (FetchException | JAXBException e) {
			e.printStackTrace();
		}
	}

}
