package com.cisco.prj.client;

import java.util.Date;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.file.MovieDaoFileImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.PersistenceException;
import com.cisco.prj.service.MovieService;

public class AddMovieExample {
	private static Logger logger = Logger.getLogger(AddMovieExample.class);
	
	public static void main(String[] args) {
		logger.info("Main called");
		/*Movie m = new Movie(2,"Jack Sparrow",new Date());
		
//		MovieDao movieDao = new MovieDaoDbImpl();
		MovieDao movieDao = new MovieDaoFileImpl();
		
		try {
			logger.info("Main calls add movie");
			movieDao.addMovie(m);
			System.out.println("Movie added !!!");
			logger.info("Movie added...");
		} catch (PersistenceException e) {
			e.printStackTrace();
		}*/
		
		String movie = "<movie><id>3</id><name>Test</name><releaseDate>20-10-2010</releaseDate></movie>";
		MovieService movieService = new MovieService();
		try {
			movieService.xmlToMovie(movie);
		} catch (JAXBException | PersistenceException e) {
			e.printStackTrace();
		}
		
	}

}
