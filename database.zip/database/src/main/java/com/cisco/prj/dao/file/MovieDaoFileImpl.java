package com.cisco.prj.dao.file;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

// CSV format 
public class MovieDaoFileImpl implements MovieDao {

	public static String toString(Date d) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		return sdf.format(d);
	}
	
	public void addMovie(Movie movie) throws PersistenceException {
		System.out.println(movie.getReleaseDate());
		try (FileOutputStream fout = new FileOutputStream("movies.txt",true);
			PrintStream out = new PrintStream(fout);) {
			
			out.println(movie.getId() 
					+ ", " + movie.getName() 
					+ "," + toString(movie.getReleaseDate()));
		} catch(IOException e) {
			throw new PersistenceException("unable to add movie", e);
		}
	}

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
			try(FileReader reader = new FileReader("movies.txt");
				BufferedReader br = new BufferedReader(reader)) {
				String line = null;
				while( (line = br.readLine()) != null){
					String[] data = line.split(",");
					Movie m = new Movie();
					m.setId(Integer.parseInt(data[0].trim()));
					m.setName(data[1].trim());
					m.setReleaseDate(null);// not doing now...
					movies.add(m);
				}
			}catch(IOException e) {
				throw new FetchException("unable to get movie", e);
			}
		return movies;
	}

}
