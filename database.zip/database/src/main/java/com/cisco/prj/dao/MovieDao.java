/**
 * 
 */
package com.cisco.prj.dao;

import java.util.List;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

/**
 * @author Banu Prakash
 * 
 * an entity to represent movie business data.
 */
public interface MovieDao {
	
	/**
	 * method to store movie information.
	 * 
	 * @param movie movie to persist
	 * @throws PersistenceException 
	 */
	void addMovie(Movie movie) throws PersistenceException;

	/**
	 *  method to return all movies
	 * @return movies
	 * @throws FetchException
	 */
	List<Movie> getMovies() throws FetchException;
}
