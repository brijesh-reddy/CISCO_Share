/**
 * 
 */
package com.cisco.prj.dao.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class to manage database resources 
 * 
 * @author Banu Prakash
 *
 */
public class DBUtil {
	private static String DRIVER = DbConfig.getString("DBUtil.DRIVER"); //$NON-NLS-1$
	private static String URL = DbConfig.getString("DBUtil.URL"); //$NON-NLS-1$
	private static String USER = DbConfig.getString("DBUtil.USER"); //$NON-NLS-1$
	private static String PWD = DbConfig.getString("DBUtil.PWD"); //$NON-NLS-1$
	
	static {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL,USER, PWD);
	}
	
	public static void closeConnection(Connection con) {
		if( con != null ){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
