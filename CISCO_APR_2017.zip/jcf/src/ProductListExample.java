import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ProductListExample {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product(300,"iPhone 7",72000.00,"mobile"));
		products.add(new Product(120,"Samsung OLED",64000.00,"tv"));
		products.add(new Product(201,"Sony Bravia",88000.00,"tv"));
		products.add(new Product(100,"MotoG",72000.00,"mobile"));
		products.add(new Product(103,"Logitech Mouse",72000.00,"computer"));
		
		Collections.sort(products, new Comparator<Product>() {
			@Override
			public int compare(Product o1, Product o2) {
				return Double.compare(o1.getPrice(), o2.getPrice());
			}
		});
		
		Collections.reverse(products);

		/* for Each */
		for (Product product : products) {
			System.out.println(product);
		}
		/* iterator */
		Iterator<Product> iter = products.iterator();
	
		while(iter.hasNext()) {
			Product p = iter.next();
			System.out.println(p);
		}
	
		/* index [don't use this] */
		for(int i = 0; i <products.size(); i++) {
			Product p = products.get(i);
			System.out.println(p);
		}
	}

}
