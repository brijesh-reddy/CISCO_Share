import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		Map<String, Double> info = new HashMap<String, Double>();
		info.put("INFY", 560.66);
		info.put("Oracle", 6533.33);
		info.put("CISCO", 933.33);
		
		System.out.println(info.get("CISCO")); // 933.33
		
		info.put("CISCO", 1033.00);
		
		Set<String> keys = info.keySet();
		for(String key : keys) {
			System.out.println(key + ": " + info.get(key));
		}
		System.out.println("***********");
		
		Set<Entry<String,Double>> entries = info.entrySet();
		
		for(Entry<String,Double> e : entries) {
			System.out.println(e.getKey() + " : " + e.getValue());
		}
		
	}

}
