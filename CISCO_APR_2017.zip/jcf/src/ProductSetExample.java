import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ProductSetExample {

	public static void main(String[] args) {
//		Set<Product> products = new HashSet<Product>();
		Set<Product> products = new TreeSet<Product>();
		products.add(new Product(300,"iPhone 7",72000.00,"mobile"));
		products.add(new Product(120,"Samsung OLED",64000.00,"tv"));
		products.add(new Product(201,"Sony Bravia",88000.00,"tv"));
		products.add(new Product(100,"MotoG",72000.00,"mobile"));
		products.add(new Product(103,"Logitech Mouse",72000.00,"computer"));
		products.add(new Product(201,"Sony Bravia",88000.00,"tv"));
		
		/* for Each */
		for (Product product : products) {
			System.out.println(product);
		}
		
		List<Product> list = new ArrayList<Product>(products);
		
		/* iterator 
		Iterator<Product> iter = products.iterator();
	
		while(iter.hasNext()) {
			Product p = iter.next();
			System.out.println(p);
		}*/
	
	}

}
