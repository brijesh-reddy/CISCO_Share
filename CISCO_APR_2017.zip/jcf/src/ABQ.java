import java.util.concurrent.ArrayBlockingQueue;

public class ABQ {

	public static void main(String[] args) {
		ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(1);
		
		//producer
		new Thread(()-> {
			for (int i = 0; i < 10; i++) {
				try {
					queue.put(i);
					Thread.sleep((long) (Math.random()*3000));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start();
		
		//consumer
				new Thread(()-> {
					for (int i = 0; i < 10; i++) {
						try {
							System.out.println(queue.take());
							Thread.sleep((long) (Math.random()*3000));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}).start();
	}

}
