import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class SQLParser {

	public static String getCreateSQL(Class<?> clazz) {
		StringBuilder builder = new StringBuilder("create table ");
		Table table = clazz.getAnnotation(Table.class);
		if (table != null) {
			builder.append(table.name());
			builder.append("(");
			Method[] methods = clazz.getDeclaredMethods();
			for (Method m : methods) {
				if (m.getName().startsWith("get")) {
					Column col = m.getAnnotation(Column.class);
					if (col != null) {
						builder.append(col.name());
						builder.append(" ");
						builder.append(col.type());
						builder.append(", ");
					}
				}
			}
			builder.setCharAt(builder.lastIndexOf(","), ')');
		}

		return builder.toString();
	}

	public static String getInsertSQL(Object obj) {
		StringBuilder builder = new StringBuilder("insert into ");
		Table table = obj.getClass().getAnnotation(Table.class);
		if (table != null) {
			builder.append(table.name());
			builder.append(" values (");
			Method[] methods = obj.getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.getName().startsWith("get")) {
					Column col = m.getAnnotation(Column.class);
					if (col != null) {
						try {
							Object ret = m.invoke(obj, null);
							if (ret instanceof String) {
								builder.append("'" + ret + "'");
							} else {
								builder.append(ret);
							}
							builder.append(",");
						} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
							e.printStackTrace();
						}
					}
				}
			}
			builder.setCharAt(builder.lastIndexOf(","), ')');
		}
		return builder.toString();
	}

}
