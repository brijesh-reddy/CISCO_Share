
public class Ex {

	public static void main(String[] args) {
		int x = 10;
		int y = 2;
		if(x> 1 | y > 1)
		System.out.println(z);
	}

}
