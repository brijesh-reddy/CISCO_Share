import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		String[] names = {"Brad","Lee","Angelina","Larry","George"};
		/*List<String> list = new ArrayList<String>();
		list.add("Brad");
		list.add("Lee");
		list.add("Angelina");
		list.add("Larry");
		list.add("George");*/
		List<String> list = Arrays.asList(names);
		Collections.sort(list, new  Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				int diff = o1.length() - o2.length();
				return diff;
			}
		});
		
		for (String name : list) {
			System.out.println(name);
		}
	}

}
