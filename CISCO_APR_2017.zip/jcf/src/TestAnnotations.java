
public class TestAnnotations {

	public static void main(String[] args) {
		String sql = SQLParser.getCreateSQL(Product.class);
		System.out.println(sql);
		
		Product p = new Product(123,"iPhone 7",75000.00,"mobile");
		sql  = SQLParser.getInsertSQL(p);
		System.out.println(sql);
	}

}
