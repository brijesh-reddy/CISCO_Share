import java.util.Arrays;
import java.util.Comparator;

public class ArrayExample {

	public static void main(String[] args) {
		 
		String s1 = "Aa";
		String s2 = "BB";
		String s3 = "Hello";
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		
		/*String[] names = {"Brad","Lee","Angelina","Larry","George"};
		
		Arrays.sort(names, new  Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				int diff = o1.length() - o2.length();
				return diff;
			}
		});
 
		for(String name : names) {
			System.out.println(name);
		}
		*/
	}
}
/*
class LengthComparator implements Comparator<String> {
	@Override
	public int compare(String o1, String o2) {
		int diff = o1.length() - o2.length();
		return diff;
	}
	
}*/
