import java.util.ArrayList;
import java.util.List;

public class TestCollection {

	public static void main(String[] args) {
		List<Integer> iList = new ArrayList<Integer>();
		iList.add(1);iList.add(12);iList.add(21);
		
		List<String> sList = new ArrayList<String>();
		sList.add("Hello"); sList.add("World");
		print(iList);
		print(sList);
		
		List<Integer> itList = new ArrayList<>();
		List<String> stList = new ArrayList<>();
		
		copy(itList, iList);
		copy(stList, sList);
		print(itList);
		print(stList);
		
	}
	private static void print(List<?> list) {
		for (int i = 0; i <list.size() ; i++) {
			System.out.println(list.get(i));
		}
	}
   //PECS Producer Extends Consumer Super
	private static <T> void copy(List<? super T> target, List<? extends T> src) {
		for(T o : src) {
			target.add(o);
		}
	}
}
