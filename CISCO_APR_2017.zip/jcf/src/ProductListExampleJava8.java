import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProductListExampleJava8 {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product(300, "iPhone 7", 72000.00, "mobile"));
		products.add(new Product(120, "Samsung OLED", 64000.00, "tv"));
		products.add(new Product(201, "Sony Bravia", 88000.00, "tv"));
		products.add(new Product(100, "MotoG", 72000.00, "mobile"));
		products.add(new Product(103, "Logitech Mouse", 72000.00, "computer"));
		
		
		List<Product> mobiles = products.parallelStream()
		.filter(p -> p.getCategory().equals("mobile")).collect(Collectors.toList());
		
		mobiles.forEach(m -> System.out.println(m.getName()));
		
		System.out.println("&&&&&&&&&&&");
		
		double total = products.parallelStream()
		.filter(p -> p.getCategory().equals("mobile"))
		.map(p -> p.getPrice()).reduce(0.0, (p1,p2) -> p1+p2);
		
		System.out.println(total);
		
		Map<String,List<Product>> map = 
				products.stream().collect(Collectors.groupingBy(p -> p.getCategory()));
		
		map.forEach((k, v) -> {
			System.out.println("Category : " + k);
			v.forEach(p -> {
				System.out.println(p.getName() + ", "+ p.getPrice());
			});
		});
		
		/*products.parallelStream()
		.filter(p -> p.getCategory().equals("mobile"))
		.forEach(p -> System.out.println(p.getName() + ", " + p.getPrice()));
		
		
		products.parallelStream()
		.filter(p -> p.getCategory().equals("mobile"))
		.map(p -> p.getName())
		.forEach(p -> System.out.println(p));
		*/
		
	/*	Collections.sort(products, (o1, o2) -> {
			return Double.compare(o1.getPrice(), o2.getPrice());
		});

		products.stream().map(p -> {
			return p.getName();
		}).forEach(name -> System.out.println(name));

		products.stream().map(p -> {
			Product temp = new Product();
			temp.setId(p.getId());
			temp.setName(p.getName());
			temp.setPrice(p.getPrice() + 99.00);
			temp.setCategory(p.getCategory());
			return temp;
		}).forEach(p -> System.out.println(p.getName() + ", " + p.getPrice()));

		Function<Product, Product> func = (p) -> {
			Product temp = new Product();
			temp.setId(p.getId());
			temp.setName(p.getName());
			temp.setPrice(p.getPrice() + 99.00);
			temp.setCategory(p.getCategory());
			return temp;
		};

		Consumer<Product> cons = new Consumer<Product>() {
			@Override
			public void accept(Product p) {
				System.out.println(p.getName() + ", " + p.getPrice());
			}

		};
		Consumer<Product> cons2 = (p) -> {
			System.out.println(p.getName() + ", " + p.getPrice());
		};

		products.stream().map(func).forEach(cons);*/

		/*
		 * for Each for (Product product : products) {
		 * System.out.println(product); }
		 */

	}

}
