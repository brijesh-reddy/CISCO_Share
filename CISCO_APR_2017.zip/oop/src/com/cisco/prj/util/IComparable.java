package com.cisco.prj.util;

public interface IComparable {
	int difference(Object other);
}
