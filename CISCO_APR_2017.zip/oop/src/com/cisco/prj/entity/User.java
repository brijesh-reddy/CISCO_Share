package com.cisco.prj.entity;

import com.cisco.prj.util.IComparable;

public class User implements IComparable {
	private int id;
	private String name;

	public User() {
	}

	public User(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int difference(Object other) {
		User u = (User) other;
//		return this.id - u.id;
		return this.name.compareTo(u.name);
	}
}
