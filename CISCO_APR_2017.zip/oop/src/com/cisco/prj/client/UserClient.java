package com.cisco.prj.client;

import com.cisco.prj.dao.UserDao;
import com.cisco.prj.dao.UserDaoFactory;
import com.cisco.prj.entity.User;

public class UserClient {

	public static void main(String[] args) {
		User user = new User(100,"Smith"); // from UI
//		UserDao userDao = new UserDaoCloudImpl();
		UserDao userDao = UserDaoFactory.getUserDao();
		userDao.register(user);
		
	}

}
