package com.cisco.prj.client;

import com.cisco.prj.entity.User;
import com.cisco.prj.util.Utility;

public class SortClient {

	public static void main(String[] args) {
		User[] users = new User[3];
		users[0] = new User(134,"Smith");
		users[1] = new User(340,"Allen");
		users[2] = new User(100,"Peter");
		
		Utility.sort(users);
		
		for(User u : users) {
			System.out.println(u.getId() + ", " + u.getName());
		}
	}

}
