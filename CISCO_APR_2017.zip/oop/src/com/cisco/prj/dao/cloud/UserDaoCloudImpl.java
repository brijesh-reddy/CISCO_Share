package com.cisco.prj.dao.cloud;

import com.cisco.prj.dao.UserDao;
import com.cisco.prj.entity.User;

public class UserDaoCloudImpl implements UserDao {

	@Override
	public void register(User user) {
		System.out.println("User " + user.getName() + " saved in cloud!!!");
	}

}
