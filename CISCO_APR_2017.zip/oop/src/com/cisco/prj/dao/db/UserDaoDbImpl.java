package com.cisco.prj.dao.db;

import com.cisco.prj.dao.UserDao;
import com.cisco.prj.entity.User;

public class UserDaoDbImpl implements UserDao {

	@Override
	public void register(User user) {
		System.out.println("User " + user.getName() + " saved in database!!!");
	}

}
