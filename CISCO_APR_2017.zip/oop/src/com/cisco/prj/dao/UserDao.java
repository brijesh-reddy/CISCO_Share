package com.cisco.prj.dao;

import com.cisco.prj.entity.User;

public interface UserDao {
	void register(User user);
}
