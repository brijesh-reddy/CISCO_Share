package com.cisco.prj.dao;

import java.util.ResourceBundle;

public class UserDaoFactory {
	private static String USER_DAO = "";

	static {
		ResourceBundle res = ResourceBundle.getBundle("database");
		USER_DAO = res.getString("USER_DAO").trim();
	}

	public static UserDao getUserDao() {
		// return new UserDaoCloudImpl();
		try {
			return (UserDao) Class.forName(USER_DAO).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
