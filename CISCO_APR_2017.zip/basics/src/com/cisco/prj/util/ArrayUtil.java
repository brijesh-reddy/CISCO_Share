package com.cisco.prj.util;

public class ArrayUtil {
	
	public static int getSum(int[] data) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			sum += data[i];
		}
		return sum;
	}
	
	public static int getOccurrence(int[] data, int no) {
		int count = 0;
		for (int i = 0; i < data.length; i++) {
			if(data[i] == no) {
				count++;
			}
		}
		return count;
	}
	
	public static void sort(int[] data) {
		for (int i = 0; i < data.length; i++) {
			for (int j = i + 1 ; j < data.length; j++) {
				if(data[i] > data[j]) {
					int swap = data[i];
					data[i] = data[j];
					data[j] = swap;
				}
			}
		}
	}
}
