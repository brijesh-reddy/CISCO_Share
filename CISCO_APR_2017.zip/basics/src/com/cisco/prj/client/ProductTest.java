package com.cisco.prj.client;

import com.cisco.prj.entity.Mobile;
import com.cisco.prj.entity.Product;
import com.cisco.prj.entity.Tv;

public class ProductTest {

	public static void main(String[] args) {
		Product products[] = new Product[4]; // creates 4 references
		products[0] = new Mobile(100, "MotoG", 12999.99, "4G"); // upcasting
		products[1] = new Tv(101, "Sony Bravia", 75000.00, "LED"); // upcasting
		products[2] = new Mobile(102, "iPhone 7", 72000.00, "4G"); // upcasting
		products[3] = new Tv(103, "Onida", 2500.00, "CRT"); // upcasting
		
		for (int i = 0; i < products.length; i++) {
//			if (products[i] != null) {
				System.out.println(products[i].getName() + ", " + products[i].getPrice());
				if (products[i] instanceof Mobile) {
					Mobile m = (Mobile) products[i]; // downcasting
					System.out.println(m.getConnectivity());
				}
				if (products[i].getClass() == Tv.class) {
					Tv t = (Tv) products[i];
					System.out.println(t.getScreenType());
				}
				if (products[i].isExpensive()) { // dynamic binding [
													// Polymorphic ]
					System.out.println("Expensive Product");
				} else {
					System.out.println("Not expensive Product");
				}
//			}
		}
	}

}
