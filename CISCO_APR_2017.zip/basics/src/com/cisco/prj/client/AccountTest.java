package com.cisco.prj.client;

import com.cisco.prj.entity.Account;

public class AccountTest {

	public static void main(String[] args) {
		System.out.println(Account.getCount());
		Account first = new Account();
		System.out.println(Account.getCount());
		Account second = new Account("SB100");
		System.out.println(Account.getCount());
		Account third  = new Account("SB100");
		System.out.println(Account.getCount());
		Account fourth = second;
		if(fourth == second) {
			System.out.println("Fourth and Second are same");
		}
		if(second.equals(third)){
			System.out.println("second and third have same content");
		}
		first.deposit(5600.00);
		second.deposit(3500.00);
		
		System.out.println("First Account");
		System.out.println("Acc NO:" + first.getAccNo());
		System.out.println(first.getBalance());
	
		System.out.println("Second Account");
		System.out.println("Acc NO:" + second.getAccNo());
		System.out.println(second.getBalance());
	}

}
