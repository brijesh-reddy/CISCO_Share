/**
 * 
 */
package com.cisco.prj.entity;

/**
 * @author Banu Prakash
 * @version 1.0
 * 
 * Account entity class to represent account business data. 
 */
public class Account {
	private String accNo; // state of an object [ instance variables ]
	private double balance; // state of an object [ instance variables ]
	private static int count = 0; // state of class [ class memeber ]
	
	//default
	public Account() {
		/*this.accNo = "NA";
		this.balance = 0.0;*/
		this("NA");
	}
	
	// parameterized
	public Account(String no) {
		count++;
	 	this.accNo = no;
		this.balance = 0.0; 
	}
	
	
	/**
	 * 
	 * @param amt amount to credit into account
	 * 
	 * Method to credit.
	 */
	public void deposit(double amt) {
		this.balance += amt;
	}
	
	/**
	 * 
	 * @return current balance
	 */
	public double getBalance() {
		return this.balance;
	}
	
	public String getAccNo() {
		return this.accNo;
	}

	@Override
	public boolean equals(Object obj) {
		Account other = (Account) obj;
		return this.accNo.equals(other.accNo);
	}
	
	public static int getCount() {
		return count;
	}
}
