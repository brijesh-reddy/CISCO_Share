package com.cisco.prj.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayUtilTest {

	@Test
	public void testGetSum() {
		int[] values = {4,6,2,-10};
		int expected  = 2;
		assertEquals(expected, ArrayUtil.getSum(values));
		
		int[] data = {10,20,30};
		expected = 60;
		assertEquals(expected, ArrayUtil.getSum(data));
	}

	@Test
	public void testGetOccurrence() {
		int[] values = {4,6,2,-10,4,1,4};
		int expected  = 3;
		assertEquals(expected, ArrayUtil.getOccurrence(values, 4));
	}

	@Test
	public void testSort() {
		int[] values = {4,6,2,-10,4,1,4};
		int[] expected = { -10,1,2,4,4,4,6};
		ArrayUtil.sort(values);
		assertArrayEquals(expected, values);
	}

}
