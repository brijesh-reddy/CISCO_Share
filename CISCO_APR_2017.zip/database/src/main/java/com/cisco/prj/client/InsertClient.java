package com.cisco.prj.client;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.csv.MovieDaoCsvImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.PersistenceException;

public class InsertClient {

	public static void main(String[] args) {
		Movie movie = new Movie(5, "Kabil", 2017);
		MovieDao movieDao = new MovieDaoCsvImpl();

		try {
			movieDao.addMovie(movie);
			System.out.println("Movie inserted !!!!");
		} catch (PersistenceException e) {
			e.printStackTrace(); // for developer
			System.out.println(e.getMessage()); // for user
		}
	}

}
