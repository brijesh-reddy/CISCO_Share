package com.cisco.prj.dao.csv;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public class MovieDaoCsvImpl implements MovieDao {

	public void addMovie(Movie movie) throws PersistenceException {
		try {
			FileOutputStream fout = new FileOutputStream("movies.csv",true);
			PrintStream ps = new PrintStream(fout);
			ps.println(movie.getId() +", " + movie.getName() + ", " + movie.getYear());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			FileReader reader = new FileReader("movies.csv");
			BufferedReader br = new BufferedReader(reader);
			String line = null;
			while( (line = br.readLine()) != null) {
				String[] data = line.split(",");
				Movie m = new Movie();
				m.setId(Integer.parseInt(data[0].trim()));
				m.setName(data[1].trim());
				m.setYear(Integer.parseInt(data[2].trim()));
				movies.add(m);
			}
		} catch (IOException e) {
			throw new FetchException("unable to get movies", e);
		}
		
		return movies;
	}

}
