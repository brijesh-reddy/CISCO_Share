package com.cisco.prj.dao.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.exception.PersistenceException;

public class MovieDaoDbImpl implements MovieDao {

	public void addMovie(Movie movie) throws PersistenceException {
		String SQL = "insert into MOVIES values (0,?,?)";
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.setString(1, movie.getName());
			ps.setInt(2, movie.getYear());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("unable to add movie", e);
		} finally {
			DBUtil.closeConnection(con);
		}
	}

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
		String SQL = "select ID, NAME, YEAR from MOVIES";
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				Movie m = 
						new Movie(rs.getInt("ID"), rs.getString("NAME"), rs.getInt("YEAR"));
				movies.add(m);
			}
		} catch (SQLException e) {
			throw new FetchException("unable to fetch movies", e);
		} finally {
			DBUtil.closeConnection(con);
		}
		return movies;
	}

}
