package com.cisco.prj.client;

import java.util.List;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.dao.csv.MovieDaoCsvImpl;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;

public class ReadClient {

	public static void main(String[] args) {
//		MovieDao movieDao = new MovieDaoDbImpl();
		MovieDao movieDao = new MovieDaoCsvImpl();

		try {
			List<Movie> movies = movieDao.getMovies();
			for (Movie m : movies) {
				System.out.println(m.getId() + ", " + m.getName() + ", " + m.getYear());
			}
		} catch (FetchException e) {
			e.printStackTrace();
		}

	}

}
