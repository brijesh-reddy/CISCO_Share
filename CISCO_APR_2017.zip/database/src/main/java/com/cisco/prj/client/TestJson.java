package com.cisco.prj.client;

import com.cisco.prj.entity.Movie;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestJson {

	public static void main(String[] args) throws Exception {
		/*Movie m = new Movie(23,"Test",2012);
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(System.out, m);*/
		
		String str = "{\"id\":24,\"name\":\"Best\",\"year\":2016}";
		
		ObjectMapper m2 = new ObjectMapper();
		Movie mov = m2.readValue(str, Movie.class);
		System.out.println(mov.getName());
		
	}

}
