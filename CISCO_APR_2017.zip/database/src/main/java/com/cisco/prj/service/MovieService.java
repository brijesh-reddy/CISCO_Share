package com.cisco.prj.service;

import com.cisco.prj.dao.MovieDao;

public class MovieService {
	private MovieDao movieDao;

	public void setMovieDao(MovieDao movieDao) {
		this.movieDao = movieDao;
	}

	public int getCount() {
		try {
			return movieDao.getMovies().size();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
