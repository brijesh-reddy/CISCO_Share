package database;

import java.util.List;

import org.junit.Test;
import static org.mockito.Mockito.*;

public class ListTest {

	@Test
	public void testList() {
		List<Integer> list =  mock(List.class);
		
		list.add(11);
		list.add(55);
		list.add(11);
		
		verify(list, times(2)).add(11);
		verify(list, times(1)).add(55);
		
		
	}

}
