package database;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;

import com.cisco.prj.dao.MovieDao;
import com.cisco.prj.entity.Movie;
import com.cisco.prj.exception.FetchException;
import com.cisco.prj.service.MovieService;

public class MovieTest {
	MovieDao movieDao;
	MovieService movieService = new MovieService();
	@Test
	public void testAddMove() {
		movieDao = mock(MovieDao.class);
		movieService.setMovieDao(movieDao);
		try {
			when(movieDao.getMovies())
				.thenReturn(Arrays.asList(new Movie(1,"A",122), new Movie(1,"A",122)));
			
			assertEquals(2,movieService.getCount());
		} catch (FetchException e) {
			e.printStackTrace();
		}
		
	}

}
