package exceptions;

public class Util {
	public static int divide(int x, int y) {
		return x /y;
	}
	
	public static int getVal(int[] data, int pos) {
		return data[pos];
	}
}
