package exceptions;

public class UncheckeExample {

	public static void main(String[] args) {
		int x = 10;
		int y = 0;
		if (y != 0) {
			int res = x / y;
		}
	}

}
