package exceptions;

public class ErrorExample {

	static {
		// System.loadLibrary("d3.dll");
	}

	public static void main(String[] args) {
		doTask();
	}

	private static void doTask() {
		System.out.println("Hello!!!");
		doTask(); //recursive
	}

}
