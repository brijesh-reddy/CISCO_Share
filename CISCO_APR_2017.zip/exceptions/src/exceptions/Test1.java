package exceptions;

public class Test1 {

	public static void main(String[] args) {
		doTask();
	}

	private static void doTask() {
		Util.divide(5, 2);
		Util.getVal(new int[] { 3, 5 }, 0);
	}
}
