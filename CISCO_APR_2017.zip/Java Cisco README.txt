			Core Java
			----------
			Banu Prakash C
			banuprakashc@yahoo.co.in
			banu@advantech-global.com
-------------------------------------------------------------------------------

Course Coverage Overview:
Introdution
OOP
Exception handling
Java Collections
Threads and IO
JDBC
Java 8 features

Softwares Required:
JDK 1.8
Eclipse for JEE [ Mars or Neon]
Mysql Database Communitity Edition [ 4th Day ]
----------------------------------------------------

OOP [ Abstraction, Encapsulation, Inheritance and Polymorphism]
Programs which resemble real world applications.

SOLID Design Principles:

S --> Single Responsibility
O --> Open Close Principle
L --> Liskov Substitution Principle
I --> Interface Seggregation
D --> Dependency Injection

---------------------------------------------

What is Java?

Java Compile time environment
Java Runtime Environment

	Class Loader methods:
		findLoadedClass()
		loadClass()
		findSystemClass()
		defineClass()

	Employee.java

	public class Employee {
		private int id;
		private String name;

		public void info() {
			int x;
			// code
		}
	}

	Test.java

	public class Test {
		public static void main(String[] args) {
			Employee e1 = new Employee();
			e1.info();
			Employee e2 = new Employee();
			e2.info();
		}
	}
------------------------------------------------------
	Java Types

	Primitive [ Memory on Stack]		Reference Type [Heap area and its pointers on Stack]


	Singed types
	byte 
	short - 2 bytes
	int - 4
	long - 8

	float - 4
	double - 8


	unsigned
	char - 2 bytes

	boolean [ true / false ]

	Java is Strongly typed.
	-----------------------------------------------

	Referrence Types: class , interface, Array

	Arrays:

	int[] data = new int[4];

//	int[] values = {34,3,6, 61};

	int x[3]; // error

	int [] values = data;

-----------------------------------------------------

Packages are used for class namespace identification, without packages classes are
not re-usable
Packages are used to group related classes.

Logical grouping of classes:
1) Entity and DTO [ Data Transfer Object ]
2) DAO [ Data Access Object ]
3) Business
4) Service
5) Utility
6) Exception
7) UI

------
Comments:
	1) Single line
		int age; // age of person

	2) Multiline
		/*
			code for validating	
			user and password
		*/

	3) JavaDoc comments

		/**
			Class to represent Account entity
			@author banu prakash
			@version 1.0
			@lastUpdated 12-2-2017
		*/
		public class Account {

			/**
				Method to credit amt to account
				@param amt Amount to credit
			*/
			public void deposit(double amt) {

			}

		}
---------------------------------------------
Object identity:

== Vs equals() methods

String s1 = new String("Hello");
String s2 = new String("Hello");
String s3 = s1;


s1 == s3; // true
s1 == s2; // false

s1.equals(s2); // true
s1.equals(s3); // true

-----------------------------------------------

Unit Testing
Frameworks for Unit testing: JUnit, TestNG
-----------------------------------------------

Relationship between objects:
1) Generalization and Specialization [ Inheritance ]
2) Association
	Composition or Aggregation
3) Uses A


	---------------

	public class Product {
		public Product() {
			"A";
		}
		public Product(int id) {
			"A1";
		}
	}

	public class Mobile extends Product {
		public Mobile() {
			super();
			"M";
		}
		public Mobile(int id, String camera) {
			super(id);
			"M1";
		}
	}

	new Mobile();
	new Mobile(100,"12MP"); //A1 M1

	-------------

	public class Product {
		public int getPrice() {
			return 100;
		}
		public String getName( ) {
			return "A1";
		}
	}

	public class Mobile extends Product {
		public int getPrice() {
			return 999;
		}
		public String getCamera() {
			return "24MP";
		}
	}

	Mobile m = new Mobile();
	m.getPrice(); // 999
	m.getName(); .. A1
	m.getCamera(); // 24MP

	Product p = new Mobile();
	p.getPrice(); // 999
	p.getName(); .. A1
	p.getCamera(); // ERROR

-------------------------------

Day 2

abstract class and methods

Visibility

public: can be accessed from everwhere
	
private: limited access within a class

default: package-private // can be accessed by all the classes within the package

protected: package-private + any inherited classes [ can be outside package ]

1) Generalization and Specialization Relationship using Inheritance [ extends ]
	Note: 
	1) Java Does not support multiple inheritance
	2) Object is the root class for every class [ Single root hierarchy ]

2) Realization relationship
	a component will realize the behaviour specified by other in order to communicate

	interface is used to establish the relaization relationship
 
	Why Program to interface?
		1) DESIGN
		2) IMPLEMENTATION
		3) TESTING
		4) INTEGRATION


	interface interfaceName {
		abstract methods
	}


	Example:

	interface EmployeeDao {
		void addEmployee(Employee e);
		Employee getEmployee(int id);
	}


	Class loaders loads a class if is referenced.
	String str  ="com.cisco.prj.dao.cloud.UserDaoCloudImpl";

	Class.forName(str); //loads the class programitically
	Object obj = Class.forName(str).newInstance();
-----------------------------------------------------------------------------------------------


 Example:

 interface Swim {											Dance d = new Dance(); // error
 	swim();													Dance d = new Actor(); // valid
 }															Dance d = new Hero();
 																  d.dance();			
 interface Dance {													d.fight(); // 
 	dance();
 }

 interface Fight {
 	fight();
 }

// actor is capable of dancing
class Actor implements Dance {
	dance ()  { ... }		
}

// hero is a actor
class Hero extends Actor implements Swim, Fight{
	swim() {...} fight() {... }
}

---------------------
OCP
 need to sort n products

 	void sort(Product[] products) {

 	}

need to sort n employees

	void sort(Employee[] employees) {

	} 

Can this be a solution

	void sort(Object[] objs) {

	} 
-------
	What do you do to sort?

	interface IComparable {
		int difference(Object obj);
	}

	void sort(IComparable[] objs) {

	} 


	public class Employee  implements IComparable{
		int difference(Object obj) { }
	}

	public class Product  implements IComparable {
		int difference(Object obj) { }
	}
	Employee[] emps = ....

	Product[] prods = ...
----------------------------------------------------------------

	Exception Handling
	------------------

	An abnormal condition taht arises during program execution is an exception.

	In Java exception is an object.
	Excpetion Object:
		1) What went wrong
		2) Why
		3) Where

	Error and Exception type of exceptions.

	Exceptions can be again classfied as "Checked Type" and "Unchecked Type"


	Unchecked Type of exceptions:
	1) Compiler does not enforce you to handle them
	2) These types of exceptions occur duew to reasons within JRE
		Example: ArithmeticException, NullPointerException, ArrayIndexOutOfBoundsException
	3) Oracle/Sun MS recommends you to handle these type of exceptions using conditional statement

	CheckedType of Exceptions:
	1) Compiler forces you to handle.
		try {
			actual code
		} catch(ExcpetionType1 e1 ) {

		}  catch(ExcpetionType1 e2) {
		
		} finally {

		}
	
	2) These type of exceptions occur due to reasons outside JRE
		Example: FileNotFoundException, SQLException, ClassNotFoundException
---------------------------------------------------------------------------------
	Generics

	public class Rectangle {
		int width;
		int breadth;
		///
	}


	public class DRectangle {
		double width;
		double breadth;
		///
	}

	public class Rectangle <T> {		public class Rectangle  {
		T width;								Object width;
		T breadth;								Object breadth;
		///
	}



	Rectangle<Integer> r1 = new Rectangle<Integer>(4,5);

	Rectangle<Double> r2 = new Rectangle<Double>(4.3,5.5);	

    Recatngle<String> r3 = new Reactangle<String>("Hello", "World"); // we don't need this


    public class Rectangle <T extends Number> {		public class Rectangle  {
		T width;											Number width;
		T breadth;											Number breadth;
		///
	}

	 Recatngle<String> r3 = new Reactangle<String>("Hello", "World"); // error

	----------------------------------------------------------------------------

	Arrays are covariant, but generics are not covariant

	Object[] objs = new String[3]; // covariance


	Rectangle<Object> r1 = new Rectangle<Integer>(); // error

---------------------------------------------------------------------

Day 3:
-----

Java Collection Framework [ Data Containers ]

Array is a data container.
Array Size is fixed, it can't grow nor shrink.

int[] data = new int[100];

Adding/ Removing from arbitrary position is difficult
It needs contiguous memory location
----------------------

Java Collection Framework was introducted in Java 1.2 version
It provides various types of conntainers which are inter-operable.
In Java Collection Framework contains:
1) interfaces
2) Implementation classes
3) Algorithm classes [ Utilities like binarySearch, sort, max, min, etc...]

interface Iterator {
		boolean hasNext();
		Object next();
}

 interface Collection {
 	add(..)
 	remove(..)
 	Iterator iterator();
 }

 interface Dance {
 	dance();
 }

 interface Fight extends Dance {
 	fight();
 }

 class Hero implements Fight {
 	fight() {}
 	dance() { }
 }

---

List 									Set
1) Supports duplicates					unique
2) supports index-based oper 			won't
3) Ordered 								not-ordered
4) Re-ordered




  names:

   "Brad", "Angelina", "Lee", "Kumar"

   Sorted O/p:
   Angelina
   Brad
   Kumar
   Lee

   Why not?
   Lee
   Brad
   Kumar
   Angelina



interface Comparator {
	int compare(Object o1, Object o2);
}

public class Test implements Comparator {
		public int compare(Object o1, Object o2) {
			Test t1 = (Test) o1;
			Test t2 = (Test) o2;
		}
}

interface Comparator<T> {
	int compare(T o1, T o2);
}

public class Test implements Comparator<Test> {
		public int compare(Test o1, Test o2) {
		 
		}
}
-----------------------------------
Anonymous class: Class without a name

interface Flyable {
	fly();
}

Flyable f = new Flyable(); // is this valid ???

class Bird implements Flyable {
		fly() { }
}

Flyable f = new Bird(); // valid



class Dummy implements Flyable {
		fly() { }
}

Flyable f = new Dummy();

Flyable f = new Flyable() {
	fly() { .... }
}

=====================================

 ArrayList list = new ArrayList();

 LinkedList list = new LinkedList();

 List list = new ArrayList(); // prefer [ program to interface ]

 list.add(11); // valid
 list.add("Sam"); // valid
 list.add(new Date()); // valid

 Prefer Generic collections:

 List<String> list = new ArrayList<String>(); // TypeSafe

 list.add("Sam"); // valid
 list.add(new Date()); // invalid



-----------

HashCode:
	Numerical representation of an Object
	1) If two objects are similar then their hash codes has to same
	2) two disimilar objects can also have same hashcode

-----------------------------------------------------------

Annotations

	Annotations are meta-data

	Example:
	@Override

	Annotaions can be used by:
		1) Compiler
		2) Classloader
		3) JRE
	Annotactions can be applied to:
		1) TYPE [ class , interface , annotation ]
		2) constructors
		3) methods
		4) variables




@Mobile(os="andriod")
public class PokemonGo extends Game {
	
}


@RequestMapping(value="/customers",method="POST")
public class OrderController {
	
}


@RequestMapping(value="/customers" )
public class CustomerController {
	
}


http://server/custoemrs

---------------------


public @interface RequestMapping {
	String value();
	String method() default "GET";
}
------------------------------------------------------------------------

























@Table(name="PRDS")
public class Product   {
   //
 
 	@Column(name="PRD_ID", type="NUMERIC(10)")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="PRD_NAME", type="VARCHAR(255)")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

https://github.com/BanuPrakash/CISCO_Share
---------------------------------------------
	Java Concurrent Programming [ Multi-threaded applications]

	Process should have atleast one unit of work.
	Main Thread is the first thread to start in a process.

	Why?
		1) To avoid starvation
		2) Optimization of usage of available resource

	Runnable interface

	interface Runnable {
		void run();
	}

	class SpellChecker implemnets Runnable {

			run() {.... }
	}

	--------
	Thread class contains thread control methods:
	1) start();
	2) sleep(long ms)
	3) yield()
	4) interrupt()
	5) join()

	deprecated methods:
	6) suspend()
	7) resume()
	8) stop()
---------------------------
	
 	Thread Safety:

 	A member is said to be thread safe if it does not get corrupted in concurrent access.

 	Local Varialbes : Safe [ reside in stack, every thread has a seperate stack]

 	static var : Not safe [ Method Area, shared be threads]

 	instance var: not Safe [Heap, shared]

 	volatile var: safe [ Heap area]



 	 public  void withdraw(String name, double amt) {
		System.out.println(name + " trying to withdraw "  + amt);
		System.out.println(name +" getting balance");
		synchronized(this) {
			double bal = getBalance();
			System.out.println(name  +" got balance " + bal);
			bal -= amt;
			System.out.println(name + " setting balance : " + bal);
			setBalance(bal);
		}
		
	}
	

 
	class BankingService {

		SB100  SB105   50000
		SB105  SB100    88888
		public void transferFunds(Account from, Account to, double amt) {
				synchronized(from) {
					synchronized(to) {
						//
					}
				}
		}

	}
-------------------------------

	Lock APIs [ Doug Lea ]

	Java 1.5 version introduced Lock API, which can be used instead of synchronized.
	Why lock API?
	Limitations of synchronized.
	1) Only one lock per object
	2) Only owner can release the lock
	3) can result in deadlocks
----------------------------------------------------------------------------------------------

Java Database Connectivity [ JDBC ]
 JDBC is an integration API to connection Java Applications with RDBMS

 Different Ways of connecting to database:

 Type 1:

  Java app <----> JDBC <---> JDBC ODBC Bridge <----> ODBC <----> Database/

  	ODBC : Open database connectivity, api's provided by Microsoft

 Type 2:
 	Java app <----> JDBC <---> Native Drivers <---> DB

 		Native drivers are provided by database vendors

 Type 3:
 	Java app <----> JDBC <---> Middle tier Net Driver <--> DB
 	JNDI 

 Type 4:
 	Java app <----> JDBC <---> Pure Java Socket connection <--- > DB
 	Database vendors provide Java implementation classes for JAVA interfaces

-----------------------------
	Java provides:

	1) DriverManager class
			to establish database connection
	2) Connection interface
	
		Connection con = DriverManager.getConnection(URI, user, password);

	3) Statement, PreparedStatment and CallableStatement interfaces for sending SQL

		Statement is for "FIXED SQL"
		like: "select * from EMP"

		PreparedStatment is for SQL with IN PARAMETERS
		like: "insert into EMP values (?,?,?)"

		Pre-compile and cache it
		also known as Parameterized statment

		select * from users where username = ? and password = ?

		String sql = "select * from users where username =" + u + "and password = " + p; // avoid


		CallableStatement is for invoking StoredProcedures of database.

	4) ResultSet
		is a cursor to fetched records from DB
		this is a result of "SELECT " statement
--------------------------

ObjectMapper mapper = new ObjectMapper();
			CollectionType javaType = mapper.getTypeFactory()
				      .constructCollectionType(List.class, Movie.class);
			
			list = mapper.readValue(builder.toString(), javaType);


mysql> set password=password('secret123');



mysql> create database CISCO_APR_2017;
mysql> use CISCO_APR_2017;

mysql> create table MOVIES (id int PRIMARY KEY AUTO_INCREMENT, NAME VARCHAR(100), YEAR int);


mysql> insert into MOVIES values(0,'Life Of PI', 2014);
mysql> insert into MOVIES values(0, 'Avengers', 2015);
mysql> select * from MOVIES;

--------------------------------

CSV storage

JSON:
JavaScript Object Notation
JSON understands the following types:
number, string, boolean, null, object
JSON is a key:value pair:
Emmployee object:

	{
		"id": 1,
		"name": "Smith"
	}

Collection of employees:
	[
		{}, {}, {}
	]

RESTful webservices

Java <---> JSON
	APIs
	1) Jackson
	2) Jettison
	3) GSON
	4) MOXY
--------------------------------------------------------

	Java 8 introduced functional style of programming

	In OOP methods use state of object

	Functional style of programming does not use state


 	In functional style of programming uses high order functions 
 	[ functions which accepts other functions as arguments]

 	As of Java 1.7
 		to a method we can pass primitive or object

 	Java 8 introduced Lambda expression

 	Thread t1 = new Thread(new Runnable() {
 		public void run() {
 			System.out.println("Hello");
 		}
 	});


 	Thread t1 = new Thread( () -> System.out.println("Hello"));


 	FunctionalInterface is an interface which contains only one method to implement


 	interface Comparable {
 		int compareTo(Object obj);
 	}

 	MAP   ( modify the collection ) 
 		is a high order functions which accepts mapping function
 	FILTER
 		is a high order function which accepts predicate function
 	SORT

 	REDUCE
 	ITERATOR

 	p ->  p.getName() 

 	p -> {return p.getName();}

 	String mapping(Product p) {
 		return g.getName();
 	}


































































































































































































































