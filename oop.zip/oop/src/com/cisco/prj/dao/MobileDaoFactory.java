/**
 * 
 */
package com.cisco.prj.dao;

import java.util.ResourceBundle;

/**
 * @author Banu Prakash
 *
 */
public class MobileDaoFactory {
	
	private static String DAO_CLASS = "";
	
	static {
		ResourceBundle res = ResourceBundle.getBundle("dbconfig");
		DAO_CLASS = res.getString("MOBILE_DAO").trim();
	}
	
	/**
	 *  Factory class to instantiate implementation class
	 *  of MobileDao.
	 *  
	 * @return instance of MobileDao
	 */
	public static MobileDao getMobileDao() {
//		return new MobileDaoCloudImpl();
		try {
			return (MobileDao) Class.forName(DAO_CLASS).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}



