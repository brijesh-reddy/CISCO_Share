/**
 * 
 */
package com.cisco.prj.dao;

import com.cisco.prj.entity.Mobile;

/**
 * @author Banu Prakash
 *
 */
public class MobileDaoCloudImpl implements MobileDao {

	/* (non-Javadoc)
	 * @see com.cisco.prj.dao.MobileDao#addMobile(com.cisco.prj.entity.Mobile)
	 */
	@Override
	public void addMobile(Mobile mobile) {
		System.out.println("Stored on Cloud :" + mobile.getName());
	}

}
