package com.cisco.prj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cisco.prj.entity.Product;

public class ProductDaoJdbcImpl implements ProductDao {
	private static String INSERT_SQL = "INSERT INTO PRODUCT VALUES(0,?,?,?)";
	private static String SELECT_SQL = "SELECT id, name, prce, category FROM PRODUCT";

	public List<Product> getProducts() throws DaoException {
		List<Product> products = new ArrayList<Product>();
		Connection con = null;
		try {
			con = DBUtil.getCon();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SELECT_SQL);
			while (rs.next()) {
				Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getDouble("price"),
						rs.getString("category"));
				products.add(p);
			}
		} catch (SQLException e) {
			throw new DaoException("unable to get prds", e);
		} finally {
			DBUtil.closeConnection(con);
		}
		return products;
	}

	public void addProduct(Product product) throws DaoException {
		Connection con = null;
		try {
			con = DBUtil.getCon();
			PreparedStatement ps = con.prepareStatement(INSERT_SQL);
			ps.setString(1, product.getName());
			ps.setDouble(2, product.getPrice());
			ps.setString(3, product.getCategory());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new DaoException("unable to add product", e);
		} finally {
			DBUtil.closeConnection(con);
		}
	}

}
