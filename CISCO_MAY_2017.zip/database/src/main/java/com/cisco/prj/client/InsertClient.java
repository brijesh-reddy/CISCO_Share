package com.cisco.prj.client;

import com.cisco.prj.dao.DaoException;
import com.cisco.prj.dao.ProductDao;
import com.cisco.prj.dao.ProductDaoJdbcImpl;
import com.cisco.prj.entity.Product;

public class InsertClient {

	public static void main(String[] args) {
		ProductDao dao = new ProductDaoJdbcImpl();
		try {
			 Product p = new Product(0,"test",222.22,"tv");
			 dao.addProduct(p);
			 System.out.println("Product added!!!!");
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

}
