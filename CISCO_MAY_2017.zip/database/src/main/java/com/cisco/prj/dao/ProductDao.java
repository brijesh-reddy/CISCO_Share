package com.cisco.prj.dao;

import java.util.List;

import com.cisco.prj.entity.Product;

public interface ProductDao {
		List<Product> getProducts() throws DaoException;
		void addProduct(Product product) throws DaoException;
}
