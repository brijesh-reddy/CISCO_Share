package exception;

public class ErrorTwo {

	public static void main(String[] args) {
		doTask();
	}

	private static void doTask() {
		System.out.println("Hello!!!");
		doTask();
	}

}
