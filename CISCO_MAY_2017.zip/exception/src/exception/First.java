package exception;

public class First {

	public static void main(String[] args) {
		int x = 10;
		int y = 0;
		
		if( y != 0) {
			int result = x / y;
			System.out.println("Result " + result);
		}
	}

}
