package exception;

public class ErrorOne {
	
	static {
		System.loadLibrary("CandyCrush.dll");
	}
	public static void main(String[] args) {
		System.out.println("Hello!!!");
	}

}
