package exception;

public class Second {

	public static void main(String[] args) {
		int[] data = {4,6,7,8};
		print(data);
	}

	private static void print(int[] data) {
		System.out.println(data[8]);
	}

}
