import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayCodeTest {

	@Test
	public void testGetSum() {
		 int[] values = {3,5,2,10};
		 int expectedSum = 20;
		 assertEquals(expectedSum, ArrayCode.getSum(values));
	}

	@Test
	public void testSort() {
		 int[] values = {3,5,2,10};
		 int[] expected = {2,3,5,10};
		 ArrayCode.sort(values);
		 assertArrayEquals(expected, values);
	}

	@Test
	public void testGetOccurence() {
		fail("Not yet implemented");
	}

}
