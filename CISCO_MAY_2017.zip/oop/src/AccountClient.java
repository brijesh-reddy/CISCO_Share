
public class AccountClient {

	public static void main(String[] args) {
		Account one = new Account("sb500");
		Account two = new Account("sb500");
		if(one == two) {
			System.out.println("one and two same ");
		}
		
		if(one.equals(two)) {
			System.out.println("one and two same content !!!");
		}
		doTask();
		System.out.println("End....");
	}

	private static void doTask() {
		Account rahulAcc = new Account("SB100");
		System.out.println(Account.getCount());
		Account swethaAcc = new Account();
		System.out.println(Account.getCount());
		
		
		rahulAcc.deposit(5500.00);
		swethaAcc.deposit(3500.00);
		rahulAcc.withdraw(750.00);
		
		System.out.println("Rahul Account details:");
		System.out.println("Acc :" + rahulAcc.getAccNo());
		System.out.println("Balance : " + rahulAcc.getBalance());
		
		System.out.println("Swetha Account details:");
		System.out.println("Balance : " + swethaAcc.getBalance());
		rahulAcc  = null;
		System.gc(); // request to Garbage collector
		
		
	}
	

}
