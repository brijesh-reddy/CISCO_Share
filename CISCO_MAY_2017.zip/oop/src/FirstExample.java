
public class FirstExample {

	public static void main(String[] args) {
		int x = 10;
		int y = 15;
		
		int result = add(x,y);
		System.out.println("Result :" + result);
	}
	
	static int add(int a, int b) {
		int sum = 0;
		sum = a + b;
		return sum;
	}

}
