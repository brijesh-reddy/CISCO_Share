
public class ArrayCode {
	public static int getSum(int[] data) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			sum += data[i];
		}
		return sum;
	}

	public static void sort(int[] data) {
		for (int i = 0; i < data.length; i++) {
			for (int j = i + 1; j < data.length; j++) {
				if(data[i] > data[j]) {
					int swap = data[i];
					data[i] = data[j];
					data[j] = swap;
				}
			}
		}
	}

	public static int getOccurence(int[] data, int no) {
		int occurs = 0;

		return occurs;
	}
}
