
public class Account {
	private double balance; // state [ instance variable]
	private String accNo; // state [ instance variable]
	private static int count; // class member [ state of class]
	
	//parameterized constructor
	public Account(String no) {
		count++;
		this.accNo = no;
	}
	//default
	public Account() {
		count++;
		this.accNo = "NA";
	}
	public void deposit(double amt) {//public void deposit(Account this, double amt) {
		balance += amt;				// this.balance += amt;
	}
	
	public void withdraw(double amt) {
		this.balance -= amt;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public String getAccNo() {
		return this.accNo;
	}
	
	public static  int getCount() {
		return count;
	}
	
	public boolean equals(Object arg) {
		Account other = (Account) arg;
		if(this.accNo.equals(other.accNo)) {
			return true;
		}
		return false;
	}
}
