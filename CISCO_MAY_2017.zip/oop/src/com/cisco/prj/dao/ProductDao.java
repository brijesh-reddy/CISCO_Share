package com.cisco.prj.dao;

import com.cisco.prj.entity.Product;

public interface ProductDao {
	void addProduct(Product product);
}
