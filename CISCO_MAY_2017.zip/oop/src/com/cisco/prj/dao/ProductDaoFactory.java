package com.cisco.prj.dao;

import java.util.ResourceBundle;

public class ProductDaoFactory {
	private static String DAO_NAME ="";
	
	static {
		ResourceBundle res = ResourceBundle.getBundle("config");
		DAO_NAME = res.getString("PRODUCT_DAO").trim();
	}
	
	public static ProductDao getProductDao() {
		try {
			return (ProductDao) Class.forName(DAO_NAME).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
