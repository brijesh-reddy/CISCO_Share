package com.cisco.prj.dao;

import com.cisco.prj.entity.Product;

public class ProductDaoCloudImpl implements ProductDao {

	@Override
	public void addProduct(Product product) {
		System.out.println(product.getName() + " saved to cloud!!!!");
	}

}
