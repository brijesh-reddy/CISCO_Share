/**
 * 
 */
package com.cisco.prj.entity;

/**
 * This is an entity class to represent mobile data.
 * 
 * @author Banu Prakash
 * @since 1.0
 * @version 1.0
 */
public class Mobile extends Product {
	private String connnectivity;

	public Mobile() {
	}

	public Mobile(int id, String name, double price, String connnectivity) {
		super(id, name, price);
		this.connnectivity = connnectivity;
	}

	/**
	 * @return the connnectivity
	 */
	public String getConnnectivity() {
		return connnectivity;
	}

	/**
	 * @param connnectivity the connnectivity to set
	 */
	public void setConnnectivity(String connnectivity) {
		this.connnectivity = connnectivity;
	}

	/* (non-Javadoc)
	 * @see com.cisco.prj.entity.Product#isExpensive()
	 */
	@Override
	public boolean isExpensive() {
		if(getConnnectivity().equals("3G") && getPrice() > 6000) {
			return true;
		} else if("4G".equals(getConnnectivity()) && getPrice() > 20000) {
			return true;
		}
		return false;
	}
}
