package com.cisco.prj.util;

public class Utility {
	// OCP Sort function is closed for a change
	public static void sort(IComparable[] elems) {
		for (int i = 0; i < elems.length; i++) {
			for (int j = i + 1; j < elems.length; j++) {
				if(elems[i].difference(elems[j]) > 0) {
					IComparable swap = elems[i];
					elems[i] = elems[j];
					elems[j] = swap;
				}
			}
		}
	}
}
