package com.cisco.prj.util;

public interface IComparable <T> {
	int difference(T obj);
}
