package com.cisco.prj.client;

import com.cisco.prj.entity.Mobile;
import com.cisco.prj.entity.Product;
import com.cisco.prj.entity.Tv;
import com.cisco.prj.util.Utility;

public class ProductClient {

	public static void main(String[] args) {
		Product[] products = new Product[4];
		products[0] = new Mobile(100,"iPhone 7",75000.00,"4G");
		products[1] = new Tv(101,"Onida Thunder",2750.00,"CRT");
		products[2] = new Mobile(102,"MotoG",15000.00,"4G");
		products[3] = new Tv(103,"Sony Bravia",62750.00,"LED");
		
		Utility.sort(products);
		
		print(products);
		findExpensiveProducts(products);
	}

	private static void findExpensiveProducts(Product[] products) {
		for (int i = 0; i < products.length; i++) {
			if(products[i].isExpensive()) {
				System.out.println(products[i].getName() + " is costly");
			} else {
				System.out.println(products[i].getName() + " is cheap");
			}
		}
	}

	private static void print(Product[] products) {
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i].getName() + ":" + products[i].getPrice());
			if(products[i] instanceof Mobile) {
				Mobile m = (Mobile) products[i];
				System.out.println(m.getConnnectivity());
			} else if( products[i].getClass() == Tv.class) {
				Tv t = (Tv) products[i];
				System.out.println(t.getScreenType());
			}
			
		}
	}
}
