package com.cisco.prj.client;

import com.cisco.prj.entity.Book;
import com.cisco.prj.util.Utility;

public class BookClient {

	public static void main(String[] args) {
		Book[] books = new Book[4];
		books[0] = new Book(3512,"Spring");
		books[1] = new Book(5224,"Basic");
		books[2] = new Book(63434,"Dexter");
		
 		Utility.sort(books);
		
		for (int i = 0; i < books.length; i++) {
			System.out.println(books[i]);
		}
	}

}
