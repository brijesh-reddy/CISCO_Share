package com.cisco.prj.client;

import com.cisco.prj.dao.ProductDao;
import com.cisco.prj.dao.ProductDaoFactory;
import com.cisco.prj.entity.Mobile;
import com.cisco.prj.entity.Product;

public class InterfaceExample {

	public static void main(String[] args) {
		Product product = new Mobile(1,"Honor 8",12000.00,"4G");
		
//		ProductDao productDao = new ProductDaoCloudImpl();
		ProductDao productDao = ProductDaoFactory.getProductDao();
		
		productDao.addProduct(product);
	}

}
