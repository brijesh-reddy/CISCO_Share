package io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileExample {

	public static void main(String[] args) {
		int data = -1;
		try (FileInputStream fis = new FileInputStream("text.txt");
				FileOutputStream fout = new FileOutputStream("data.txt", true)) {
			while ((data = fis.read()) != -1) {
				System.out.print((char) data);
				fout.write(data);
			}
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
