package io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerialExample {

	public static void main(String[] args) {
		try (FileOutputStream fout = new FileOutputStream("customer.ser");
				ObjectOutputStream out = new ObjectOutputStream(fout)) {
			Customer c = new Customer(100,"Smith","secret123");
			out.writeObject(c);
			System.out.println("customer serialized!!!");
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
