package io;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerialExample {

	public static void main(String[] args) {
		try (FileInputStream fis = new FileInputStream("customer.ser");
				ObjectInputStream in = new ObjectInputStream(fis)) {
			Customer c = (Customer) in.readObject();
			System.out.println("ID :" + c.getId());
			System.out.println("Name :" + c.getName());
			System.out.println("Password :" + c.getPassword());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}
