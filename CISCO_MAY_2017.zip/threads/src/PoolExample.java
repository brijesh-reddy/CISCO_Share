import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class PoolExample {

	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(2);
		service.submit(new Numbers(1,100));
		service.submit(new Numbers(200,250));
		service.submit(new Numbers(400,440));
		service.submit(new Numbers(1000,1050));
		Future<Integer> f1 = service.submit(new Counter(1,100));
		Future<Integer> f2 = service.submit(new Counter(400,900));
		
		try {
			System.out.println(f1.get());
			System.out.println(f2.get());
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		service.shutdown(); // don't accept any more requests
	}

}
