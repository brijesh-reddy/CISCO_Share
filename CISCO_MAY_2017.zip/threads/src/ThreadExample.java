
public class ThreadExample {

	public static void main(String[] args) {
		System.out.println("Main Starts...");
		
		Thread t1 = new Thread(new Numbers(1,20));
		t1.start();
		

		Thread t2 = new Thread(new Numbers(500,800));
		t2.setDaemon(true);
		t2.start();
		
		doTask();
	}

	private static void doTask() {
		Thread t = Thread.currentThread();
		System.out.println("Name :" + t.getName());
		System.out.println("Priority : " + t.getPriority());
		System.out.println("Group : " + t.getThreadGroup().getName());
		System.out.println("Daemon :" + t.isDaemon());
	}

}
