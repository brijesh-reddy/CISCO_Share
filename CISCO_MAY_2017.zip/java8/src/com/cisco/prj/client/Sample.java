package com.cisco.prj.client;

interface Test {
	void best();
	default void rest() {
		System.out.println("Rest impl");
	}
	default void rest1() {
		System.out.println("Rest1 impl");
	}
}
class A implements Test {
	@Override
	public void best() {
		System.out.println("Best impl");
	}
}
public class Sample {

	public static void main(String[] args) {
		 doTask(new A());
		 doTask( () -> {
			 System.out.println("new BEST!!!");
		 });
	}

	private static void doTask (Test t) {
		t.best();
		t.rest();
	}
}
