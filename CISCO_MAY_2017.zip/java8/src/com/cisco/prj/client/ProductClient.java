package com.cisco.prj.client;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cisco.prj.entity.Product;

public class ProductClient {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product(135, "iPhone 7", 73000.00, "mobile"));
		products.add(new Product(54, "Sony 4HD", 120000.00, "tv"));
		products.add(new Product(135, "Redmi", 14000.00, "mobile"));
		products.add(new Product(62, "Seagate HDD", 600.00, "computer"));
		products.add(new Product(125, "Samsung FHD", 67000.00, "tv"));
		DoubleSummaryStatistics stats = 
				products.stream()
				.collect(Collectors.summarizingDouble(p -> p.getPrice()));
		System.out.println("Max : " + stats.getMax());
		System.out.println("Min : " + stats.getMin());
		System.out.println("Avg :" + stats.getAverage());
		
		/*// Collectors
		List<Product> mobiles = products.parallelStream()
		.filter(p -> p.getCategory().equals("mobile"))
		.collect(Collectors.toList());
		
		for(Product p : mobiles) {
			System.out.println(p.getName() + ": " + p.getCategory());
		}
		System.out.println("***********");
		Map<String, List<Product>> pmap = 
				products.stream()
				.collect(Collectors.groupingBy(p -> p.getCategory()));
		
		pmap.forEach( (k,v) -> {
			System.out.println(k);
			v.forEach(p -> {
				System.out.println(p.getName() + ":" + p.getPrice());
			});
		});*/
		
		/*products.stream().map((p) -> p.getName()).forEach(name -> System.out.println(name));

		products.stream().filter(p -> p.getCategory().equals("mobile"))
				.forEach(p -> System.out.println(p.getName() + " : " + p.getCategory()));

		double total = products.stream().map(p -> p.getPrice()).reduce(0.0, (p1, p2) -> p1 + p2);

		System.out.println("Total cost of all the products : " + total);

		total = products.parallelStream()
				.filter(p -> p.getCategory().equals("mobile"))
				.map(p -> p.getPrice())
				.reduce(0.0,(p1, p2) -> p1 + p2);

		System.out.println("Total cost of  mobiles : " + total);*/
	}

}
