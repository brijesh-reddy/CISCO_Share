package com.cisco.prj.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		Map<String, Double> movieMap = new HashMap<String,Double>();
		movieMap.put("Life Of PI", 454545.55);
		movieMap.put("Spectre", 12345.00);
		movieMap.put("Avengers", 454545.55);
		movieMap.put("Pirates", 454545.55);
		movieMap.put("Avengers", 99999.99);
		
		double collection = movieMap.get("Pirates");
		System.out.println(collection);
		
		Set<String> keys = movieMap.keySet();
		for(String key : keys) {
			System.out.println(key + " : " + movieMap.get(key));
		}
		
		System.out.println("*******");
		Set<Entry<String,Double>> entries = movieMap.entrySet();
		for(Entry<String,Double> e : entries) {
			System.out.println(e.getKey() + " : " + e.getValue());
		}
	}

}
