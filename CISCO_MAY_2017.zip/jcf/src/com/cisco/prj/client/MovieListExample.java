package com.cisco.prj.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.cisco.prj.entity.Movie;

public class MovieListExample {

	public static void main(String[] args) {
		List<Movie> movies = new ArrayList<Movie>(25);
		movies.add(new Movie("PK", 650));
		movies.add(new Movie("Sultan", 850));
		movies.add(new Movie("Bahubali 1", 750));
		movies.add(new Movie("Bahubali 2", 1500));
		movies.add(new Movie("Chennai Express", 400));
		
		Collections.sort(movies, new Comparator<Movie>() {
			@Override
			public int compare(Movie o1, Movie o2) {
				return Double.compare(o2.getBoxOffice(), o1.getBoxOffice());
			}
		}); // Arrays.sort(movies);

		for (Movie movie : movies) {
			System.out.println(movie.getTitle() + " --- " + movie.getBoxOffice());
		}

		System.out.println("******** Iterator *******");
		Iterator<Movie> iter = movies.iterator();
		while (iter.hasNext()) {
			Movie movie = iter.next();
			System.out.println(movie.getTitle() + " --- " + movie.getBoxOffice());
		}

		System.out.println("***** index based [AVOID] *****");
		for (int i = 0; i < movies.size(); i++) {
			Movie movie = movies.get(i);
			System.out.println(movie.getTitle() + " --- " + movie.getBoxOffice());
		}
	}

}
