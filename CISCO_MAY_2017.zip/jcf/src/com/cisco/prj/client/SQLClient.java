package com.cisco.prj.client;

import com.cisco.prj.entity.Movie;
import com.cisco.prj.util.SQLParser;

public class SQLClient {

	public static void main(String[] args) {
		String INSERT_SQL = SQLParser.createSQL(Movie.class);
		System.out.println(INSERT_SQL);
		
		Movie m = new Movie("Beauty and Beast",4545467.77);
		
		String SQL = SQLParser.insertSQL(m);
		System.out.println(SQL);
	}

}
