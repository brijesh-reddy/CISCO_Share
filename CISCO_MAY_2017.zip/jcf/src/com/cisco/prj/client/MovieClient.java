package com.cisco.prj.client;

import java.util.Arrays;
import java.util.Comparator;

import com.cisco.prj.entity.Movie;

public class MovieClient {

	public static void main(String[] args) {
		Movie[] movies = new Movie[5];
		movies[0] = new Movie("PK",650);
		movies[1] = new Movie("Sultan",850);
		movies[2] = new Movie("Bahubali 1",750);
		movies[3] = new Movie("Bahubali 2",1500);
		movies[4] = new Movie("Chennai Express",400);
//		Arrays.sort(movies, new PriceComparator());
		Arrays.sort(movies, new Comparator<Movie>(){
			@Override
			public int compare(Movie o1, Movie o2) {
				return Double.compare(o2.getBoxOffice(), o1.getBoxOffice());
			}
		});
		for(Movie m : movies) {
			System.out.println(m.getTitle() +" -- " + m.getBoxOffice());
		}
	}
}
class PriceComparator implements Comparator<Movie> {
	@Override
	public int compare(Movie o1, Movie o2) {
		return Double.compare(o2.getBoxOffice(), o1.getBoxOffice());
	}
}
