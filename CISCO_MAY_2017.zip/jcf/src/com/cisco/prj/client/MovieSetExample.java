package com.cisco.prj.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.cisco.prj.entity.Movie;

public class MovieSetExample {

	public static void main(String[] args) {
		Set<Movie> smovies = new HashSet<Movie>();
		/*Set<Movie> movies = new TreeSet<Movie>(new Comparator<Movie>(){
			@Override
			public int compare(Movie o1, Movie o2) {
				return Double.compare(o2.getBoxOffice(), o1.getBoxOffice());
			}
		});*/

		smovies.add(new Movie("PK", 650));
		smovies.add(new Movie("Sultan", 850));
		smovies.add(new Movie("Bahubali 1", 750));
		smovies.add(new Movie("Bahubali 2", 1500));
		smovies.add(new Movie("Chennai Express", 400));
		smovies.add(new Movie("Sultan", 850));
		
		List<Movie> movies = new ArrayList<Movie>(smovies);
		Collections.sort(movies);
		Collections.reverse(movies);
		for (Movie movie : movies) {
			System.out.println(movie.getTitle() + " --- " + movie.getBoxOffice());
		}

		System.out.println("******** Iterator *******");
		Iterator<Movie> iter = movies.iterator();
		while (iter.hasNext()) {
			Movie movie = iter.next();
			System.out.println(movie.getTitle() + " --- " + movie.getBoxOffice());
		}

	}

}
