package com.cisco.prj.entity;

import com.cisco.prj.annotations.Column;
import com.cisco.prj.annotations.Table;

@Table(name="EMP")
public class Employee {
	int id;
	String name;
	double sal;
	@Column(name="EMP_ID", type="INT")
	public int getId() {
		return id;
	}
	@Column(name="EMP_NAME")
	public String getName() {
		return name;
	}
	@Column(name="SALARY", type="NUMERIC(12,2)")
	public double getSal() {
		return sal;
	}
	
	
}
