package com.cisco.prj.entity;

import com.cisco.prj.annotations.Column;
import com.cisco.prj.annotations.Table;

@Table(name="MOVIES")
public class Movie implements Comparable<Movie> {
	private String title;
	private double boxOffice;
	public Movie() {
	}
	public Movie(String title, double boxOffice) {
		this.title = title;
		this.boxOffice = boxOffice;
	}
	@Column(name="MOVIE_TITLE")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="COLLECTIONS", type="NUMERIC(12,2)")
	public double getBoxOffice() {
		return boxOffice;
	}
	public void setBoxOffice(double boxOffice) {
		this.boxOffice = boxOffice;
	}
	@Override
	public int compareTo(Movie o) {
		return this.title.compareTo(o.title);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(boxOffice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (Double.doubleToLongBits(boxOffice) != Double.doubleToLongBits(other.boxOffice))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	
	
}
