package com.cisco.prj.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.cisco.prj.annotations.Column;
import com.cisco.prj.annotations.Table;

public class SQLParser {

	public static String createSQL(Class<?> clazz) {
		StringBuilder builder = new StringBuilder();
			Table table = clazz.getAnnotation(Table.class);
			if(table != null) {
				builder.append("CREATE TABLE ");
				builder.append(table.name());
				builder.append("(");
				Method[] methods = clazz.getDeclaredMethods();
				for(Method m : methods) {
					if(m.getName().startsWith("get")){
						Column c = m.getAnnotation(Column.class);
						builder.append(c.name());
						builder.append(" ");
						builder.append(c.type());
						builder.append(", ");
					}
				}
				builder.setCharAt(builder.lastIndexOf(","), ')');
			}
		return builder.toString();
	}
	
	public static String insertSQL(Object obj) {
		StringBuilder builder = new StringBuilder();
		Table table = obj.getClass().getAnnotation(Table.class);
		if(table != null) {
			builder.append("INSERT INTO ");
			builder.append(table.name());
			builder.append(" VALUES (");
			Method[] methods = obj.getClass().getDeclaredMethods();
			for(Method m : methods) {
				if(m.getName().startsWith("get")){
					try {
						Object ret = m.invoke(obj, new Object[]{});
						if(ret instanceof String) {
							builder.append("'" + ret + "'");
						} else {
							builder.append(ret);
						}
						builder.append(",");
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
						e.printStackTrace();
					}
				}
			}
			builder.setCharAt(builder.lastIndexOf(","), ')');
		}
		return builder.toString();
	}
	
}
